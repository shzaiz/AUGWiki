#include<bits/stdc++.h>
#define P 998244353
#define ll long long
using namespace std;
ll n,m,a[202][4002]={0},sum[202]={0};
ll tot=1,dp[202][402]={0},c=0;
int main(){
	cin>>n>>m;
	for(ll i=1;i<=n;i++){
		for(ll j=1;j<=m;j++){
			cin>>a[i][j];
			sum[i]=(sum[i]+a[i][j])%P;
		}
		tot=(tot*(sum[i]+1))%P;
	}
	tot=(tot+P-1)%P;
	for(ll p=1;p<=m;p++){
		memset(dp,sizeof(dp),0); 
		dp[0][100]=1;
		for(ll i=1;i<=n;i++){
			for(ll d=100-i;d<=100+i;d++){
				dp[i][d]=dp[i-1][d];
				dp[i][d]=(dp[i][d]+dp[i-1][d-1]*a[i][p]+P)%P;
				dp[i][d]=(dp[i][d]+dp[i-1][d+1]*(sum[i]-a[i][p])+P)%P;
				dp[i][d]=(dp[i][d]+P)%P;
			}
		}
		for(ll d=100+1;d<=100+n;d++){
			tot=(tot+P-dp[n][d])%P;
		}
	}
	cout<<tot;
	return 0;
}