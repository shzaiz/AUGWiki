#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;
typedef long long LL;
#define MAXN 100003
LL dp[MAXN], c[5], d[5], s;
inline int f(int id) {
    return c[id] * (d[id] + 1);
}
int main() {
    ios::sync_with_stdio(0);
    cin.tie(0);
    dp[0] = 1;    
    cin>>c[1]>>c[2]>>c[3]>>c[4];
    for(int i = 1; i <= 4; ++i)
        for(int j = c[i]; j <= MAXN; ++j)
                dp[j] += dp[j - c[i]];
    int T;
    cin>>T;
    while(T--) {
        cin>>d[1]>>d[2]>>d[3]>>d[4]>>s;
        LL ans = dp[s];
        if(s >= f(1)) ans -= dp[s - f(1)];
        if(s >= f(2)) ans -= dp[s - f(2)];
        if(s >= f(3)) ans -= dp[s - f(3)];
        if(s >= f(4)) ans -= dp[s - f(4)];
        if(s >= f(1) + f(2)) ans += dp[s - f(1) - f(2)];
        if(s >= f(1) + f(3)) ans += dp[s - f(1) - f(3)];
        if(s >= f(1) + f(4)) ans += dp[s - f(1) - f(4)];
        if(s >= f(2) + f(3)) ans += dp[s - f(2) - f(3)];
        if(s >= f(2) + f(4)) ans += dp[s - f(2) - f(4)];
        if(s >= f(3) + f(4)) ans += dp[s - f(3) - f(4)];
        if(s >= f(1) + f(2) + f(3)) ans -= dp[s - f(1) - f(2) - f(3)];
        if(s >= f(1) + f(2) + f(4)) ans -= dp[s - f(1) - f(2) - f(4)];
        if(s >= f(1) + f(3) + f(4)) ans -= dp[s - f(1) - f(3) - f(4)]; 
        if(s >= f(2) + f(3) + f(4)) ans -= dp[s - f(2) - f(3) - f(4)];
        if(s >= f(1) + f(2) + f(3) + f(4)) ans += dp[s - f(1) - f(2) - f(3) - f(4)];
        cout<<ans<<endl;
    }
    return 0;
}