#include <iostream>
#include <vector>

using namespace std;

vector<int> f[550]; // f[i]表示第i个Catalan数
int len = 1;

void add(int u) {
    int carry = 0;
    for (int i = 0; i < len; i++) {
        if (i >= f[u].size()) f[u].push_back(0);
        if (i >= f[u - 1].size()) f[u - 1].push_back(0);
        f[u][i] += f[u - 1][i] + carry;
        carry = f[u][i] / 10;
        f[u][i] %= 10;
    }
    while (carry) {
        f[u].push_back(carry % 10);
        carry /= 10;
    }
    len = max(len, (int)f[u].size());
}

int main() {
    int n;
    cin >> n;

    f[1].push_back(1); // 初始化第一个Catalan数

    for (int i = 2; i <= n + 1; i++) {
        for (int j = 1; j <= i; j++) {
            add(j);
        }
    }

    for (int i = f[n].size() - 1; i >= 0; i--) {
        cout << f[n][i];
    }

    cout << endl;

    return 0;
}
