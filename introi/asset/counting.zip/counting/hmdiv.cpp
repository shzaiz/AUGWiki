#include <bits/stdc++.h>
using namespace std;
#define MAXN 100010
#define pb push_back
#define LL long long
#define INF 0x3f3f3f3f
#define int long long
#define fi first
#define se second
#define F(i,j,k) for(int i=j;i<=k;i++)
#define Fd(i,j,k) for(int i=j;i>=k;i--)
#define MOD 1000000007
void solve();
int addm(int a, int b){return (a%MOD+b%MOD)%MOD;}
int subm(int a, int b){return MOD+(a%MOD-b%MOD)%MOD;}
int mulm(int a, int b){return (a%MOD*b%MOD)%MOD;}
signed main(){
    #ifdef XBZAKIOI
    freopen("D:\\Testcases\\in.ac","r",stdin);
    freopen("D:\\Testcases\\out.ac","w",stdout);
    #endif
    solve();
}
void solve(){
    int n; 
    while(cin>>n)
    {int ans = 0;
    int a[4] = {3, 5, 11, 13};
    F(i, 0, (1<<4)-1){
        int s = n, cnt =0;
        F(j, 0, 4-1){
            if((i>>j) & 1) {
                s/=a[j];
                cnt++;
            }
        }
        if(cnt%2==0)ans += s;
        else ans -= s;   
    }
    cout<<ans<<endl;}
}