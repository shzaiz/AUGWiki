#include<iostream>
#include<cstdio>
#include<cstring>

using namespace std;

const int MAXN = 41;
const int MAXM = 501;
const long long p = 998244353;

long long n, m, a[MAXN][MAXM], sum[MAXN], f[MAXN][MAXN][MAXN];
long long ans = 1, cd;

long long dp(int i, int j, int k, int c) {
    // 边界条件
    if (i == 0) return (j == 0 && k == 0) ? 1 : 0;
    if (j < 0 || k < 0) return 0;

    // 如果已经计算过，直接返回
    if (f[i][j][k] != -1) return f[i][j][k];

    // 计算当前状态
    long long res = dp(i - 1, j, k, c) % p; // 不选当前行
    if (j > 0)
        res = (res + a[i][c] * dp(i - 1, j - 1, k, c) % p) % p; // 选第c列
    if (k > 0)
        res = (res + (sum[i] - a[i][c]) * dp(i - 1, j, k - 1, c) % p) % p; // 不选第c列
    
    return f[i][j][k] = res;
}

int main() {
    scanf("%lld%lld", &n, &m);
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            scanf("%lld", &a[i][j]);
            sum[i] = (sum[i] + a[i][j]) % p;
        }
        ans = (ans * (sum[i] + 1) % p) % p; // 总方案数
    }
    
    for (int c = 1; c <= m; c++) {
        memset(f, -1, sizeof(f)); // 初始化记忆化数组为 -1
        for (int j = 1; j <= n; j++) {
            for (int k = 0; k <= n - j; k++) {
                if (j > k) {
                    cd = (cd + dp(n, j, k, c)) % p; // 累加不合法方案
                }
            }
        }
    }
    
    printf("%lld\n", (ans - cd - 1 + p) % p); // 输出结果，注意防止负数影响
    return 0;
}
