#include <iostream>
#include <queue>
#include <vector>

using namespace std;

const int MAXN = 5000006;
int numNodes, mode, parent[MAXN], pruferSeq[MAXN], degreeCount[MAXN];
long long xorSum;

struct Node {
    int degree, id;
    bool operator<(const Node& other) const {
        return (degree != other.degree) ? (degree > other.degree) : (id > other.id);
    }
};

priority_queue<Node> pq;

void convertTreeToPrufer() {
    vector<Node> nodes(numNodes + 1);

    // 输入父节点信息，并计算每个节点的度数
    for (int i = 1; i < numNodes; ++i) {
        cin >> parent[i];
        nodes[i].id = i;
        ++nodes[parent[i]].degree;
    }
    nodes[numNodes].id = numNodes;

    // 将度数为0的节点加入优先队列
    for (int i = 1; i <= numNodes; ++i) {
        if (nodes[i].degree == 0) pq.push(nodes[i]);
    }

    // 生成Prufer序列
    for (int i = 1; i <= numNodes - 2; ++i) {
        Node currentNode = pq.top();
        pq.pop();
        pruferSeq[i] = parent[currentNode.id];
        --nodes[parent[currentNode.id]].degree;
        if (nodes[parent[currentNode.id]].degree == 0) pq.push(nodes[parent[currentNode.id]]);
        xorSum ^= static_cast<long long>(i) * pruferSeq[i];
    }

    cout << xorSum << endl;
}

void convertPruferToTree() {
    // 输入Prufer序列，并统计每个节点的出现次数
    for (int i = 1; i <= numNodes - 2; ++i) {
        cin >> pruferSeq[i];
        ++degreeCount[pruferSeq[i]];
    }
    pruferSeq[numNodes - 1] = numNodes;

    // 生成父节点数组
    for (int i = 1, j = 1; i < numNodes; ++i, ++j) {
        while (degreeCount[j]) ++j;
        parent[j] = pruferSeq[i];
        --degreeCount[pruferSeq[i]];
        while (i < numNodes && degreeCount[pruferSeq[i]] == 0 && pruferSeq[i] < j) {
            parent[pruferSeq[i]] = pruferSeq[i + 1];
            ++i;
            --degreeCount[pruferSeq[i]];
        }
    }

    for (int i = 1; i < numNodes; ++i) xorSum ^= static_cast<long long>(i) * parent[i];
    cout << xorSum;
}

int main() {
    cin.tie(nullptr);
    ios::sync_with_stdio(false);
    cin >> numNodes >> mode;
    if (mode == 1) {
        convertTreeToPrufer();
    } else {
        convertPruferToTree();
    }
    return 0;
}
