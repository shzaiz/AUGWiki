#include <stdio.h>

int main() {
  int i, j, a, lin;
  scanf("%d%d%d%d", &i, &j, &a, &lin);
  j = j - a + 1; 
  int ans = 1;
  for (int i = j - a + 1; i <= j; ++i) {
    ans = 1ll * ans * i % lin;
  }
  printf("%d\n", ans);
  return 0;
}