#include <iostream>
#include <cstdio>
#include <cstdlib>
using namespace std;
long long chart[2001][2001]={};
long long flag [2001][2001]={};
long long ans = 0;
int k;
inline void build(){
  chart[0][0]=1;
  chart[1][0]=1;
  chart[1][1]=1;
  for (int i=2;i<=2000;i++){
        chart[i][0]=1;
        for (int j=1;j<=i;j++){
            chart[i][j]=(chart[i-1][j-1]%k+chart[i-1][j]%k)%k;
            flag[i][j]=flag[i-1][j]+flag[i][j-1]-flag[i-1][j-1];
            if (chart[i][j]==0) flag[i][j]++;
        }
        flag[i][i+1]=flag[i][i];
    }
}
inline void solve(){
	int t,n,m;
  
  cin>>t>>k;
  build();
  while(t--){
    ans=0;
    cin>>n>>m;
    if(m>n) cout<<flag[n][n]<<endl;
    else cout<<flag[n][m]<<endl;
  }
}
main(){
	//freopen("problem.in","r",stdin);
    //freopen("problem.out","w",stdout); 
	solve();
}