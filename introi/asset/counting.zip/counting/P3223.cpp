#include <cstdio>
#include <vector>
#include <iostream>

#define MOD 100000000
#define ll long long

using namespace std;

void clear(vector<ll>& val) {
    while (!val.back() && val.size() > 1) val.pop_back();
}

vector<ll> add(const vector<ll>& a, const vector<ll>& b) {
    vector<ll> c(max(a.size(), b.size()) + 1, 0);
    for (int i = 0; i < c.size(); ++i) {
        if (i < a.size()) c[i] += a[i];
        if (i < b.size()) c[i] += b[i];
        if (i < c.size() - 1) {
            c[i + 1] += c[i] / MOD;
            c[i] %= MOD;
        }
    }
    clear(c);
    return c;
}

vector<ll> multiply(const vector<ll>& a, int x) {
    vector<ll> c = a;
    ll carry = 0;
    for (int i = 0; i < c.size(); ++i) {
        c[i] = c[i] * x + carry;
        carry = c[i] / MOD;
        c[i] %= MOD;
    }
    if (carry > 0) c.push_back(carry);
    clear(c);
    return c;
}

vector<ll> multiply(const vector<ll>& a, const vector<ll>& b) {
    vector<ll> c(a.size() + b.size(), 0);
    for (int i = 0; i < a.size(); ++i) {
        for (int j = 0; j < b.size(); ++j) {
            c[i + j] += a[i] * b[j];
            if (c[i + j] >= MOD) {
                c[i + j + 1] += c[i + j] / MOD;
                c[i + j] %= MOD;
            }
        }
    }
    clear(c);
    return c;
}

vector<ll> divide(const vector<ll>& a, int x) {
    vector<ll> b(a.size(), 0);
    ll remainder = 0;
    for (int i = a.size() - 1; i >= 0; --i) {
        ll current = remainder * MOD + a[i];
        b[i] = current / x;
        remainder = current % x;
    }
    clear(b);
    return b;
}

vector<ll> A(int n, int m) {
    vector<ll> result(1, 1);
    if (m > n) return vector<ll>(1, 0);
    for (int i = n - m + 1; i <= n; ++i) {
        result = multiply(result, i);
    }
    return result;
}

vector<ll> C(int n, int m) {
    vector<ll> result(1, 1);
    if (m > n) return vector<ll>(1, 0);
    for (int i = n - m + 1; i <= n; ++i) {
        result = multiply(result, i);
    }
    for (int i = 1; i <= m; ++i) {
        result = divide(result, i);
    }
    return result;
}

void output(const vector<ll>& val) {
    if (val.empty()) {
        printf("0");
        return;
    }
    printf("%lld", val.back());
    for (int i = val.size() - 2; i >= 0; --i) {
        printf("%08lld", val[i]);
    }
}

int main() {
    int n, m;
    scanf("%d%d", &n, &m);
    if (!n && !m) {
        printf("0");
        return 0;
    }
    vector<ll> ans = multiply(A(n, n), multiply(A(n + 1, 2), A(n + 3, m)));
    ans = add(ans, multiply(multiply(multiply(A(n, n), C(m, 1)), A(2, 2)), multiply(C(n + 1, 1), A(n + 2, m - 1))));
    output(ans);
    return 0;
}
