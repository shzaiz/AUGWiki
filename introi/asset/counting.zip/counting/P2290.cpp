#include <iostream>
#include <vector>

using namespace std;

int n, sum = 0, cntp = 0, p[155], cnt[155];
long long ans = 1;
bool flag[155] = {false};

vector<int> factorize(int x) {
    vector<int> factors;
    for (int i = 1; i <= cntp; i++) {
        while (x % p[i] == 0) {
            factors.push_back(p[i]);
            x /= p[i];
        }
    }
    return factors;
}

int main() {
    cin >> n;
    flag[1] = true;

    for (int i = 2; i <= n; i++) {
        if (!flag[i]) {
            for (int j = 2; j * i <= n; j++) {
                flag[i * j] = true;
            }
        }
    }

    for (int i = 2; i <= n; i++) {
        if (!flag[i]) {
            p[++cntp] = i;
        }
    }

    for (int i = 2; i <= n - 2; i++) {
        vector<int> factors = factorize(i);
        for (int j : factors) {
            cnt[j]++;
        }
    }

    for (int i = 1, d; i <= n; i++) {
        cin >> d;
        sum += d;

        for (int j = 2; j < d; j++) {
            vector<int> factors = factorize(j);
            for (int k : factors) {
                cnt[k]--;
            }
        }

        if (d > n - 1) {
            cout << '0' << endl;
            return 0;
        }
    }

    if (sum != 2 * n - 2) {
        cout << '0' << endl;
        return 0;
    }

    for (int i = 1; i <= cntp; i++) {
        for (int j = 0; j < cnt[p[i]]; j++) {
            ans *= p[i];
        }
    }

    cout << ans << endl;
    return 0;
}
