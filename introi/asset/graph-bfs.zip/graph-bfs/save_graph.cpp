// #define save_edge
#ifdef save_edge
#include <iostream>
#include <vector>
using namespace std;

struct Edge {
    int u, v;
};

vector<Edge> edges;
vector<int> adj[1000]; // 假设最多有1000个节点
bool visited[1000];

// 初始化
void init() {
    edges.clear();
    for (int i = 0; i < 1000; i++) {
        adj[i].clear();
        visited[i] = false;
    }
}

// 加边
void addEdge(int u, int v) {
    edges.push_back({u, v});
    adj[u].push_back(v);
}

// 查询是否有边相邻
bool hasEdge(int u, int v) {
    for (const auto &edge : edges) {
        if (edge.u == u && edge.v == v) return true;
    }
    return false;
}

// 深度优先搜索
void dfs(int u) {
    visited[u] = true;
    cout << u << " ";
    for (int v : adj[u]) {
        if (!visited[v]) dfs(v);
    }
}

int main() {
    init();
    addEdge(1, 2);
    addEdge(2, 3);
    addEdge(3, 4);

    cout << (hasEdge(1, 2) ? "YES" : "NO") << endl;
    cout << "DFS starting from node 1: ";
    dfs(1);
    cout << endl;

    return 0;
}

#endif

// #define sort_by_start
#ifdef sort_by_start
#include <iostream>
#include <vector>
using namespace std;

vector<int> adj[1000]; // 假设最多有1000个节点
bool visited[1000];

// 初始化
void init() {
    for (int i = 0; i < 1000; i++) {
        adj[i].clear();
        visited[i] = false;
    }
}

// 加边
void addEdge(int u, int v) {
    adj[u].push_back(v);
}

// 查询是否有边相邻
bool hasEdge(int u, int v) {
    for (int vertex : adj[u]) {
        if (vertex == v) return true;
    }
    return false;
}

// 深度优先搜索
void dfs(int u) {
    if(visited[u]) return;
    visited[u] = true;
    cout << u << " ";
    for (int v : adj[u]) {
        if (!visited[v]) dfs(v);
    }
}

int main() {
    init();
    addEdge(1, 2);
    addEdge(2, 3);
    addEdge(3, 4);

    cout << (hasEdge(1, 2) ? "YES" : "NO") << endl;
    cout << "DFS starting from node 1: ";
    dfs(1);
    cout << endl;

    return 0;
}
#endif

// #define adj_matrix
#ifdef adj_matrix
#include <iostream>
#include <vector>
using namespace std;

const int MAXN = 1000;
bool edgeMatrix[MAXN][MAXN];
vector<int> adj[MAXN]; // 假设最多有1000个节点
bool visited[MAXN];

// 初始化
void init(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            edgeMatrix[i][j] = false;
        }
        adj[i].clear();
        visited[i] = false;
    }
}

// 加边
void addEdge(int u, int v) {
    edgeMatrix[u][v] = true;
    adj[u].push_back(v);
}

// 查询是否有边相邻
bool hasEdge(int u, int v) {
    return edgeMatrix[u][v];
}

// 深度优先搜索
void dfs(int u) {
    visited[u] = true;
    cout << u << " ";
    for (int v : adj[u]) {
        if (!visited[v]) dfs(v);
    }
}

int main() {
    int n = 4; // 假设有4个节点
    init(n);
    addEdge(1, 2);
    addEdge(2, 3);
    addEdge(3, 4);

    cout << (hasEdge(1, 2) ? "YES" : "NO") << endl;
    cout << "DFS starting from node 1: ";
    dfs(1);
    cout << endl;

    return 0;
}
#endif

#define cfw
#ifdef cfw
#include <iostream>
#include <vector>
using namespace std;

const int MAXN = 1000;
struct Edge {
    int to, next;
};

Edge edges[MAXN];
int head[MAXN];
int edge_count = 0;
bool visited[MAXN];

// 初始化
void init() {
    edge_count = 0;
    for (int i = 0; i < MAXN; i++) {
        head[i] = -1;
        visited[i] = false;
    }
}

// 加边
void addEdge(int u, int v) {
    edges[edge_count] = {v, head[u]};
    head[u] = edge_count++;
}

// 查询是否有边相邻
bool hasEdge(int u, int v) {
    for (int i = head[u]; i != -1; i = edges[i].next) {
        if (edges[i].to == v) return true;
    }
    return false;
}

// 深度优先搜索
void dfs(int u) {
    visited[u] = true;
    cout << u << " ";
    for (int i = head[u]; i != -1; i = edges[i].next) {
        int v = edges[i].to;
        if (!visited[v]) dfs(v);
    }
}

int main() {
    init();
    addEdge(1, 2);
    addEdge(2, 3);
    addEdge(3, 4);

    cout << (hasEdge(1, 2) ? "YES" : "NO") << endl;
    cout << "DFS starting from node 1: ";
    dfs(1);
    cout << endl;

    return 0;
}

#endif