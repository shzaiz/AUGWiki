import sys
from collections import defaultdict



def dfs(node, parent):
    subtree_size[node] = 1
    dist_sum[node] = 0
    for neighbor in tree[node]:
        if neighbor != parent:
            dfs(neighbor, node)
            subtree_size[node] += subtree_size[neighbor]
            dist_sum[node] += dist_sum[neighbor] + subtree_size[neighbor]

def dfs2(node, parent):
    for neighbor in tree[node]:
        if neighbor != parent:
            dist_sum[neighbor] = dist_sum[node] - subtree_size[neighbor] + (n - subtree_size[neighbor])
            dfs2(neighbor, node)

n = int(input())
tree = defaultdict(list)
for _ in range(n - 1):
    a, b = map(int, input().split())
    tree[a].append(b)
    tree[b].append(a)

subtree_size = [0] * (n + 1)
dist_sum = [0] * (n + 1)

dfs(1, -1)

dfs2(1, -1)

min_dist_sum = min(dist_sum[1:])
result_node = dist_sum.index(min_dist_sum)

print(result_node, end='')
print(min_dist_sum)