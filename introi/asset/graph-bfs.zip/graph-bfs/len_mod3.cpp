#include <iostream>
#include <vector>
#include <queue>
#include <cstring>
using namespace std;

const int MAXN = 1000;

struct Edge {
    int to, nxt;
} e[MAXN];

int head[MAXN], cnt = 0;
bool visited[MAXN][3]; // 用于记录每个节点在不同层次（长度模3）上的访问情况

void adde(int u, int v) {
    cnt += 1;
    e[cnt].nxt = head[u];
    head[u] = cnt;
    e[cnt].to = v;
}

pair<bool, int> bfs(int start, int end) {
    queue<pair<int, int>> q; // pair<当前节点, 当前路径长度>
    q.push({start, 0});
    visited[start][0] = true;

    while (!q.empty()) {
        auto [node, len] = q.front();
        q.pop();

        for (int i = head[node]; i != -1; i = e[i].nxt) {
            int next_node = e[i].to;
            int next_len = len + 1;
            int next_len_mod = next_len % 3;

            if (next_node == end && next_len_mod == 0) {
                return {true, next_len};
            }

            if (!visited[next_node][next_len_mod]) {
                q.push({next_node, next_len});
                visited[next_node][next_len_mod] = true;
            }
        }
    }

    return {false, -1};
}

int main() {
    // 初始化head数组为-1
    fill(head, head + MAXN, -1);
    memset(visited, 0, sizeof(visited));

    // 添加图中的边
    adde('s' - 'a', 'w' - 'a');
    adde('s' - 'a', 'x' - 'a');
    adde('w' - 'a', 'y' - 'a');
    adde('w' - 'a', 't' - 'a');
    adde('x' - 'a', 's' - 'a');
    adde('x' - 'a', 'y' - 'a');
    adde('y' - 'a', 'z' - 'a');
    adde('z' - 'a', 't' - 'a');

    // 从节点s到t进行BFS，判断是否存在长度为3的倍数的路径
    auto result = bfs('s' - 'a', 't' - 'a');
    
    if (result.first) {
        cout<< result.second << endl;
    } else {
        cout << "-1" << endl;
    }

    return 0;
}
