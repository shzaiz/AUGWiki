#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int, int> P;

struct Node {
    P loc;
    char ch;
    int cnt, step;
};

const int MAXN = 1005;
const int directions[4][2] = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

int N, M, K;
char A[MAXN][MAXN];
bool vis[MAXN][MAXN][15];

bool isValidPosition(P p) {
    int x = p.first, y = p.second;
    return (1 <= x && x <= N && 1 <= y && y <= M);
}

int main() {
    #ifdef LOCAL
    freopen("test.in", "r", stdin);
    #endif

    cin >> N >> M >> K;
    cin.ignore(); // 忽略换行符
    for (int i = 1; i <= N; ++i) {
        for (int j = 1; j <= M; ++j) {
            A[i][j] = getchar();
        }
        getchar(); // 忽略每行结束后的换行符
    }

    queue<Node> Q;
    Q.push(Node{{1, 1}, 'A', 1, 0});
    vis[1][1][1] = true;

    while (!Q.empty()) {
        Node current = Q.front();
        Q.pop();
        P pos = current.loc;

        // 如果到达目标位置，输出步数并退出
        if (pos == P(N, M)) {
            cout << current.step << endl;
            return 0;
        }

        for (const auto& direction : directions) {
            int newX = pos.first + direction[0];
            int newY = pos.second + direction[1];

            if (!isValidPosition({newX, newY})) continue;

            if (A[newX][newY] == current.ch) {
                if (current.cnt < K && !vis[newX][newY][current.cnt + 1]) {
                    Q.push(Node{{newX, newY}, current.ch, current.cnt + 1, current.step + 1});
                    vis[newX][newY][current.cnt + 1] = true;
                }
            } else {
                if (current.cnt == K && !vis[newX][newY][1]) {
                    Q.push(Node{{newX, newY}, A[newX][newY], 1, current.step + 1});
                    vis[newX][newY][1] = true;
                }
            }
        }
    }

    cout << -1 << endl;
    return 0;
}
