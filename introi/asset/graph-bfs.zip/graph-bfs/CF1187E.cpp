#include<bits/stdc++.h>
using namespace std;
struct Edge{int nxt,v;}e[401000];
int nxt,head[201000],n,m,a,b,c;
long long dp[401000],sz[401000],maxn=-1,ans;
void adde(int u,int v){e[++nxt].v=v;e[nxt].nxt=head[u];head[u]=nxt;}
void dfs(int u,int f){
    sz[u]=1;
    for(int i=head[u];i;i=e[i].nxt){	
    	int v=e[i].v;
        if(v==f)continue;
        dfs(v,u);
        sz[u]+=sz[v];
    }
    ans+=sz[u];
}
void dfs2(int u,int f){
    for(int i=head[u];i;i=e[i].nxt){	int v=e[i].v;
        if(v==f)continue;
        dp[v]=dp[u]+n-2*sz[v];
		maxn=max(maxn,dp[v]);
        dfs2(v,u);
    }
}
int read(){
    int ans;
    int ch=getchar();
    while(ch<'0'||ch>'9')ch=getchar();
    while(ch>='0'&&ch<='9'){ans=ans*10+ch-'0';ch=getchar();}
    return ans;
}
int main(){
    cin>>n;
    for(int i=1;i<n;i++){cin>>a>>b;adde(a,b);adde(b,a);}	
    dfs(1,0);
    dp[1]=ans;
    dfs2(1,0);
    cout<<maxn;
}