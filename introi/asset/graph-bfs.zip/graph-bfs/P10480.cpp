#include <iostream>
#include <queue>
#include <bitset>
using namespace std;

const int MAXN = 30005;
int n, m, cnt = 0;
// vector<bool> -> bitset
bitset<MAXN> f[MAXN];
struct Edge { // 图的边结构体
    int from, to, pre;
} edge[MAXN];
bool book[MAXN];
int head[MAXN], in[MAXN];
queue<int> q; // 用于拓扑排序
vector<int> num;

void add_edge(int from, int to) { // 添加边
    edge[++cnt] = {from, to, head[from]};
    head[from] = cnt;
}

void dfs(int u) { 
    if (book[u]) return;
    book[u] = true;
    for (int i = head[u]; i; i = edge[i].pre) {
        dfs(edge[i].to);
        f[u] |= f[edge[i].to];
    }
}

int main() {
    scanf("%d%d", &n, &m);

    for (int i = 1; i <= n; ++i) {
        f[i][i] = true; // 初始化
    }

    for (int i = 1; i <= m; ++i) {
        int u, v;
        scanf("%d%d", &u, &v);
        in[v]++; // 入度 +1
        add_edge(u, v);
    }

    // 拓扑排序基础流程
    for (int i = 1; i <= n; ++i) {
        if (in[i] == 0) {
            q.push(i);
            num.push_back(i);
        }
    }

    while (!q.empty()) {
        int t = q.front();
        q.pop();
        for (int i = head[t]; i; i = edge[i].pre) {
            if (--in[edge[i].to] == 0) { // 入度为 0 加入队列
                q.push(edge[i].to);
                num.push_back(edge[i].to);
            }
        }
    }

    for (int i : num) { // 遍历 num 执行 dfs
        dfs(i);
    }

    for (int i = 1; i <= n; ++i) {
        printf("%d\n", f[i].count());
    }

    return 0;
}
