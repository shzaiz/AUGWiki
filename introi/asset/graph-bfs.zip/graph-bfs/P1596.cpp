#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
const int MAXN=105;
int n,m;
int ans;
char table[MAXN][MAXN];
void dfs(int x,int y){
	
	table[x][y]='.';
	for(int i=-1;i<=1;i++){
		for(int j=-1;j<=1;j++){
			if(i!=0||j!=0){
				if(x+i>=1&&x+i<=n&&y+j>=1&&y+j<=m){
					if(table[x+i][y+j]=='W')
					dfs(x+i,y+j);
				}
			}
		}
	}
	
}
signed main(){
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%s",&table[i][1]);
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=m;j++){
			if(table[i][j]=='W'){
				dfs(i,j);
				ans++;
			}
		}
	}
	printf("%d\n",ans);
}