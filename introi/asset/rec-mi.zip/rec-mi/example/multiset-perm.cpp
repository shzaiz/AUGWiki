#include <stdio.h>
#include <algorithm>

// 全局变量，最大支持100个元素
int P[100], A[100];

// 打印当前排列
void print_permutation(int n, int* P, int* A, int cur) {
    if (cur == n) {
        for (int i = 0; i < n; i++) {
            printf("%d ", A[i]);
        }
        printf("\n");
        return;
    }

    // 尝试在A[cur]中填入每个未使用的整数i
    for (int i = 0; i < n; i++) {
        if (i == 0 || P[i] != P[i - 1]) { // 防止重复递归
            int c1 = 0, c2 = 0;

            // 统计当前排列中i出现的次数
            for (int j = 0; j < cur; j++) {
                if (A[j] == P[i]) c1++;
            }

            // 统计P数组中i出现的次数
            for (int j = 0; j < n; j++) {
                if (P[i] == P[j]) c2++;
            }

            // 如果当前排列中i出现的次数小于其在P数组中的总次数，继续递归
            if (c1 < c2) {
                A[cur] = P[i];
                print_permutation(n, P, A, cur + 1);
            }
        }
    }
}

int main() {
    int n;

    // 输入排列的长度
    scanf("%d", &n);

    // 输入P数组
    for (int i = 0; i < n; i++) {
        scanf("%d", &P[i]);
    }

    // 对P数组排序，确保以字典序生成排列
    std::sort(P, P + n);

    // 调用递归函数，开始生成排列
    print_permutation(n, P, A, 0);

    return 0;
}
