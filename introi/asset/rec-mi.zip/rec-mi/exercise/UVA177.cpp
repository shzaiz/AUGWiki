#include <cassert>
#include <algorithm>
#include <string>
#include <iostream>
#include <sstream>
#include <vector>
#include <map>

using namespace std;

// 定义点和向量的结构体
struct Point {
    int x, y;
    Point(int x = 0, int y = 0) : x(x), y(y) {}
};
typedef Point Vector;

// 向量和点的操作符重载
Vector operator+ (const Vector& A, const Vector& B) { return Vector(A.x + B.x, A.y + B.y); }
Vector operator- (const Point& A, const Point& B) { return Vector(A.x - B.x, A.y - B.y); }
Vector operator* (const Vector& A, int p) { return Vector(A.x * p, A.y * p); }
bool operator== (const Point& a, const Point& b) { return a.x == b.x && a.y == b.y; }
bool operator!= (const Point& a, const Point& b) { return !(a == b); }
bool operator< (const Point& p1, const Point& p2) { return p1.x < p2.x || (p1.x == p2.x && p1.y < p2.y); }
ostream& operator<<(ostream& os, const Point& p) { return os << p.x << ',' << p.y; }

// 将点 p 围绕点 r 顺时针旋转 90 度
Point rotate(const Point& p, const Point& r) {
    Vector pv = p - r;
    return r + Vector(pv.y, -pv.x);
}

const int MAXN = 13;

// 定义线段的结构体
struct Line {
    Point start, end;
    bool vertical;

    // 将线段围绕点 r 顺时针旋转 90 度
    Line rotate(const Point& r) {
        Line ret;
        ret.start = ::rotate(start, r);
        ret.end = ::rotate(end, r);
        return ret;
    }

    // 规整化线段，保证 start 在 end 的左边或者上边
    void normalize() {
        assert(start != end);
        assert(start.x == end.x || start.y == end.y);
        vertical = (start.x == end.x);
        if (vertical) {
            if (start.y > end.y) swap(start.y, end.y);
        } else {
            if (start.x > end.x) swap(start.x, end.x);
        }
    }
};

// 定义全局变量
int n;
vector<Line> lines;

int main() {
    lines.reserve(1 << MAXN);
    
    // 读取输入，直到输入为 0
    while (cin >> n && n) {
        // 初始化起始线段
        Line l;
        l.end = Point(1, 0);
        l.vertical = false;
        lines.clear();
        lines.push_back(l);
        
        int maxY = l.start.y, minY = l.start.y;
        int minX = l.start.x, maxX = l.end.x;
        Point start = l.start, rotationPoint = l.end;

        // 生成折叠的线段
        for (int i = 0; i < n; ++i) {
            int currentSize = lines.size();
            for (int j = 0; j < currentSize; ++j) {
                Line newLine = lines[j].rotate(rotationPoint);
                newLine.normalize();
                lines.push_back(newLine);
            }
            rotationPoint = rotate(start, rotationPoint);
        }

        // 使用 map 记录每个点的字符表示
        map<Point, char> pointCharMap;
        for (auto& line : lines) {
            Point& lineStart = line.start;
            lineStart.x *= 2;
            if (line.vertical) lineStart.x--;
            minX = min(lineStart.x, minX);
            maxX = max(lineStart.x, maxX);
            minY = min(lineStart.y, minY);
            maxY = max(lineStart.y, maxY);
            pointCharMap[lineStart] = line.vertical ? '|' : '_';
        }

        // 输出结果
        string buffer;
        for (int y = maxY; y >= minY; --y) {
            buffer.clear();
            for (int x = minX; x <= maxX; ++x) {
                Point p(x, y);
                if (pointCharMap.count(p)) buffer += pointCharMap[p];
                else buffer += ' ';
            }
            // 去除行末的空格
            while (!buffer.empty() && buffer.back() == ' ') buffer.pop_back();
            cout << buffer << endl;
        }

        cout << "^" << endl;
    }
    
    return 0;
}
