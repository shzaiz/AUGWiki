#include <bits/stdc++.h>
#define int unsigned long long
using namespace std;
void g(int n,int m){
    while(n!=1ULL){
        if(m>((1ULL<<(n-1ULL))-1ULL)){
            printf("1");
            m=(pow(2ull,n)-1ull-m);n--;
        }else{
            printf("0");
            n--;
        }
    }
    if(n==1ULL && m==1ULL) {printf("1");return;}
    if(n==1ULL && m==0ULL) {printf("0");return;}
}
signed main(){
    int x,y;cin>>x>>y;
    g(x,y);
    return 0;
}