#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
// 定义节点结构体
struct Node {
    LL left, right, value;
} bt[1000002];

// 判断两棵子树是否对称
bool isSymmetric(LL node1, LL node2) {
    if (node1 == -1 && node2 == -1) return true; // 两个节点都为空，对称
    if (node1 == -1 || node2 == -1) return false; // 一个为空一个不为空，不对称
    if (bt[node1].value != bt[node2].value) return false; // 节点值不同，不对称
    // 递归判断左子树和右子树是否对称
    return isSymmetric(bt[node1].left, bt[node2].right) && isSymmetric(bt[node1].right, bt[node2].left);
}

// 递归计算子树节点数量
int countNodes(LL node) {
    if (node == -1) return 0; // 空节点，返回0
    // 递归计算左子树和右子树的节点数量并加上当前节点
    return countNodes(bt[node].left) + countNodes(bt[node].right) + 1;
}

int main() {
    int n, ans = 0;
    cin >> n;

    // 输入每个节点的值
    for (int i = 1; i <= n; i++) {
        cin >> bt[i].value;
    }

    // 输入每个节点的左右子节点
    for (int i = 1; i <= n; i++) {
        cin >> bt[i].left >> bt[i].right;
    }

    // 枚举每棵子树，判断是否对称并计算最大对称子树的节点数量
    for (int i = 1; i <= n; i++) {
        if (isSymmetric(i, i)) {
            ans = max(ans, countNodes(i));
        }
    }

    // 输出最大对称子树的节点数量
    cout << ans << endl;

    return 0;
}
