#include <bits/stdc++.h>
using namespace std;

const int maxn = 5005;

struct Node {
    int wl, wr, dl, dr;
    Node *left, *right;
} tree[maxn];  // 预先分配的节点数组

int tot;

Node* newnode() {
    if (tot >= maxn) {
        return nullptr;  // 超过最大节点数时返回空指针
    }
    return &tree[tot++];
}

Node* build() {
    Node* r = newnode();
    cin >> r->wl >> r->dl >> r->wr >> r->dr;
    if (r->wl == 0) r->left = build();
    if (r->wr == 0) r->right = build();
    return r;
}

bool blc(Node* r, int &w) {
    bool fl = true, fr = true;
    if (r->wl == 0) fl = blc(r->left, r->wl);
    if (r->wr == 0) fr = blc(r->right, r->wr);
    w = r->wl + r->wr;
    return fl && fr && r->wl * r->dl == r->wr * r->dr;
}

int T;

int main() {
    cin >> T;
    while (T--) {
        int w;
        tot = 0;
        memset(tree, 0, sizeof(tree));
        Node* root = build();
        if (blc(root, w)) cout << "YES";
        else cout << "NO";
        
        // 输出换行太坑了2333
        if(T != 0) cout<<"\n";
        cout<<"\n";
    }
    return 0;
}
