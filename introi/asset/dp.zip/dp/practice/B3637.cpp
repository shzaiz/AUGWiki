
#ifdef TAKE1
#include <iostream>
#include <algorithm>
#include <climits>
using namespace std;

const int MAXN = 5000;
int sequence[MAXN + 1];
int LISbigger[MAXN + 1][MAXN + 2]; // 多开一列

int main() {
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> sequence[i];
    }

    // 添加哨兵
    sequence[0] = INT_MIN;

    // 初始化 base cases
    for (int i = 0; i <= n; ++i) {
        LISbigger[i][n + 1] = 0;
    }

    // 计算 LISbigger
    for (int j = n; j >= 1; --j) {
        for (int i = 0; i <= j - 1; ++i) {
            int keep = 1 + LISbigger[j][j + 1];
            int skip = LISbigger[i][j + 1];
            if (sequence[i] >= sequence[j]) {
                LISbigger[i][j] = skip;
            } else {
                LISbigger[i][j] = max(keep, skip);
            }
        }
    }

    cout << LISbigger[0][1] << endl;
    return 0;
}
#else 
#include <iostream>
#include <algorithm>
#include <climits>
using namespace std;

const int MAXN = 5000;
int sequence[MAXN + 1];
int LISfirst[MAXN + 1];

int main() {
    int n;
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        cin >> sequence[i];
    }

    // 添加哨兵
    sequence[0] = INT_MIN;

    // 初始化 LISfirst 数组
    for (int i = n; i >= 0; --i) {
        LISfirst[i] = 1;
        for (int j = i + 1; j <= n; ++j) {
            if (sequence[j] > sequence[i] && 1 + LISfirst[j] > LISfirst[i]) {
                LISfirst[i] = 1 + LISfirst[j];
            }
        }
    }

    // 输出结果，不计算哨兵元素
    cout << LISfirst[0] - 1 << endl;
    return 0;
}

#endif