#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>  // 用于 memset 函数

using namespace std;

const int MAX_N = 1001;  // 最大路灯数量
long long numLamps;  // 路灯数量
long long startPos;  // 老张所处位置的路灯号
long long positions[MAX_N];  // 路灯的位置
long long power[MAX_N];  // 路灯的功率
long long totalPower[MAX_N][MAX_N];  // 从i到j的总功率
long long dp[MAX_N][MAX_N][2];  // 动态规划数组

#define LEFT 0
#define RIGHT 1

int main() {
    cin >> numLamps >> startPos;

    // 读取每盏路灯的位置和功率
    for (int i = 1; i <= numLamps; ++i) {
        cin >> positions[i] >> power[i];
    }

    // 计算从i到j的总功率
    for (int i = 1; i <= numLamps; ++i) {
        for (int j = i; j <= numLamps; ++j) {
            totalPower[i][j] = (j == i) ? power[j] : totalPower[i][j-1] + power[j];
        }
    }

    // 计算总功率的补集
    long long sumPower = totalPower[1][numLamps];
    for (int i = 1; i <= numLamps; ++i) {
        for (int j = i; j <= numLamps; ++j) {
            totalPower[i][j] = sumPower - totalPower[i][j];
        }
    }

    // 初始化动态规划数组
    memset(dp, 1, sizeof(dp));
    dp[startPos][startPos][0] = dp[startPos][startPos][1] = 0;

    // 动态规划求解
    for (int length = 2; length <= numLamps; ++length) {
        for (int i = 1; i <= numLamps - length + 1; ++i) {
            int j = i + length - 1;
            
            // 计算从i到j的最小功耗，起始位置在i
            dp[i][j][LEFT] = min(
                dp[i+1][j][LEFT] + totalPower[i+1][j] * (positions[i+1] - positions[i]),
                dp[i+1][j][RIGHT] + totalPower[i+1][j] * (positions[j] - positions[i])
            );

            // 计算从i到j的最小功耗，起始位置在j
            dp[i][j][RIGHT] = min(
                dp[i][j-1][LEFT] + totalPower[i][j-1] * (positions[j] - positions[j-1]),
                dp[i][j-1][RIGHT] + totalPower[i][j-1] * (positions[j] - positions[i])
            );
        }
    }

    // 输出最小的总功耗
    cout << min(dp[1][numLamps][0], dp[1][numLamps][1]) << endl;

    return 0;
}
