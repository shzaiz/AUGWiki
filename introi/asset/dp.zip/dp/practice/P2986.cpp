#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

const int MAX = 200100;
typedef long long ll;

ll dis[MAX], C[MAX], Q[MAX], f[MAX], Sum, Ans = LLONG_MAX;

struct Edge {
    ll v, w;
};

vector<vector<Edge>> graph(MAX);
ll N;

void addEdge(ll u, ll v, ll w) {
    graph[u].push_back({v, w});
    graph[v].push_back({u, w});
}

ll DFS(ll u, ll parent) {
    ll total = 0;
    for (const auto& edge : graph[u]) {
        ll v = edge.v;
        ll w = edge.w;
        if (v != parent) {
            ll s = DFS(v, u);
            dis[u] += dis[v] + w * s;
            total += s;
        }
    }
    return Q[u] = total + C[u];
}

void DFS2(ll u, ll parent) {
    for (const auto& edge : graph[u]) {
        ll v = edge.v;
        ll w = edge.w;
        if (v != parent) {
            f[v] = f[u] - Q[v] * w + (Sum - Q[v]) * w;
            DFS2(v, u);
        }
    }
}

int main() {
    cin >> N;
    for (ll i = 1; i <= N; ++i) {
        cin >> C[i];
        Sum += C[i];
    }
    for (ll i = 1; i < N; ++i) {
        ll u, v, w;
        cin >> u >> v >> w;
        addEdge(u, v, w);
    }

    DFS(1, -1);
    f[1] = dis[1];
    DFS2(1, -1);

    for (ll i = 1; i <= N; ++i) {
        Ans = min(Ans, f[i]);
    }

    cout << Ans << endl;

    return 0;
}
