#include <bits/stdc++.h>
using namespace std;
#define N 310
#define INF 1000000000
#define F(i, j, k) for(int (i)=(j); (i)<=(k); i++)
#define Fd(i, j, k) for(int (i)=(j); (i)>=(k); i--)


int n, s[N], f[N][N];
int main(){
    cin>>n;
    for(int i=1; i<=n; i++) cin>>s[i];
    for(int i=1; i<=n; i++) s[i]+=s[i-1];

    F(len, 1, n){
        for(int i=1; i+len-1<=n; i++){
            int l = i, r=i+len-1;
            if(len==1) continue;
            f[l][r] = INF;
            for(int k=l;k<r; k++){
                f[l][r] = min(f[l][r], f[l][k]+f[k+1][r]+(s[r]-s[l-1]));
            }
        }
    }

    cout<<f[1][n]<<endl;

    return 0;
}