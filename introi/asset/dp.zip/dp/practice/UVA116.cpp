#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>

#define INF 0x3f3f3f3f

using namespace std;

const int MAXN = 110;
int a[MAXN][MAXN], dp[MAXN][MAXN], trace[MAXN][MAXN];
int n, m;

void printPath(int i, int j) {
    if (j < m) {
        printf("%d", i + 1);
        printf(j == m - 1 ? "\n" : " ");
        printPath(trace[i][j], j + 1);
    }
}

int main() {
    while (scanf("%d%d", &n, &m) != EOF) {
        for (int i = 0; i < n; ++i)
            for (int j = 0; j < m; ++j)
                scanf("%d", &a[i][j]);

        for (int j = m - 1; j >= 0; --j) {
            for (int i = 0; i < n; ++i) {
                if (j == m - 1) {
                    dp[i][j] = a[i][j]; // 边界条件
                } else {
                    int k;
                    if (i == 0) k = n - 1;
                    else k = i - 1;

                    dp[i][j] = dp[k][j + 1] + a[i][j];
                    trace[i][j] = k;

                    if (dp[i][j] == dp[i][j + 1] + a[i][j] && i < trace[i][j])
                        trace[i][j] = i;
                    if (dp[i][j] > dp[i][j + 1] + a[i][j]) {
                        dp[i][j] = dp[i][j + 1] + a[i][j];
                        trace[i][j] = i;
                    }

                    if (i == n - 1) k = 0;
                    else k = i + 1;

                    if (dp[i][j] == dp[k][j + 1] + a[i][j] && k < trace[i][j])
                        trace[i][j] = k;
                    if (dp[i][j] > dp[k][j + 1] + a[i][j]) {
                        dp[i][j] = dp[k][j + 1] + a[i][j];
                        trace[i][j] = k;
                    }
                }
            }
        }

        int minIndex = 0;
        for (int i = 1; i < n; ++i) {
            if (dp[i][0] < dp[minIndex][0])
                minIndex = i;
        }

        printPath(minIndex, 0);
        printf("%d\n", dp[minIndex][0]);
    }

    return 0;
}
