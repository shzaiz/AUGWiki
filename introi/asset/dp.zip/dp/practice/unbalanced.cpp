#include <bits/stdc++.h>
#define inf 0x3f3f3f3f 
using namespace std;

const int MAXN = 107;
const int OFFSET = 10000;
const int MAXJ = 2 * OFFSET + 1;

int x[MAXN];
int dp[MAXN][MAXJ];

int main() {
    int n, m;
    scanf("%d%d", &n, &m);

    for (int i = 1; i <= n; ++i) {
        scanf("%d", &x[i]);
    }

    memset(dp, -inf, sizeof(dp));
    auto dp_new = &dp[0][OFFSET];  // 创建引用以支持负数索引
    dp_new[0] = 0;

    for (int i = 1; i <= n; ++i) {
        auto dp_prev = &dp[i - 1][OFFSET];  // 上一层的引用
        dp_new = &dp[i][OFFSET];  // 当前层的引用

        for (int j = -OFFSET; j <= OFFSET; ++j) {
            dp_new[j] = max(dp_new[j], dp_prev[j]);

            if (j + x[i] <= OFFSET) {
                dp_new[j + x[i]] = max(dp_new[j + x[i]], dp_prev[j] + x[i]);
            }

            if (j - x[i] >= -OFFSET) {
                dp_new[j - x[i]] = max(dp_new[j - x[i]], dp_prev[j] + x[i]);
            }
        }
    }

    int ans = 0;
    for (int i = 0; i <= m; ++i) {
        ans = max(ans, dp_new[i]);
        ans = max(ans, dp_new[-i]);
    }

    printf("%d\n", ans);
    return 0;
}
