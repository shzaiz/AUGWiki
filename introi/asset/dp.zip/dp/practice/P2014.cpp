#include <iostream>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;

const int MAXN = 1005;

struct Edge {
    int to;
};

vector<Edge> graph[MAXN];
int val[MAXN], dp[MAXN][MAXN];

void addEdge(int u, int v) {
    graph[u].push_back({v});
}

void dfs(int u, int t) {
    if (t <= 0) return;
    for (auto &edge : graph[u]) {
        int v = edge.to;
        for (int k = 0; k < t; ++k) {
            dp[v][k] = dp[u][k] + val[v];
        }
        dfs(v, t - 1);
        for (int k = 1; k <= t; ++k) {
            dp[u][k] = max(dp[u][k], dp[v][k - 1]);
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;

    memset(dp, 0, sizeof(dp));

    for (int i = 1; i <= n; ++i) {
        int a;
        cin >> a >> val[i];
        if (a) {
            addEdge(a, i);
        } else {
            addEdge(0, i);
        }
    }

    dfs(0, m);
    cout << dp[0][m] << endl;

    return 0;
}
