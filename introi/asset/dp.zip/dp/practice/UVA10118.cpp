#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50;
int f[MAXN][MAXN][MAXN][MAXN]; // f[i][j][k][l] 表示前 i, j, k, l 四堆糖果的最大对数
int n;
int a[MAXN][5], top[5]; // a[i][j] 表示第 i 层第 j 堆的糖果颜色，top[j] 表示第 j 堆的顶层
bool t[MAXN]; // 用于判断编号为 x 的糖果是否已位于篮子里

int work(int num) { // num 表示篮子里的糖果数量
    int &now = f[top[1]][top[2]][top[3]][top[4]]; // now 是 f[top[1]][top[2]][top[3]][top[4]] 的引用
    if (now != -1) return now; // 如果已经计算过，直接返回
    if (num > 4) return now = 0; // 篮子最多只能装 5 颗糖果，超出则返回 0
    now = 0; // 清零，因为原数组用 -1 表示未修改过
    for (int i = 1; i <= 4; i++) { // 枚举四堆糖果，模拟取顶上的糖果并进行递归
        if (top[i] < n) { // 如果第 i 堆糖果还有
            top[i]++; // 取一个
            int c = a[top[i]][i]; // c 表示当前取的糖果颜色
            if (t[c]) { // 如果篮子里已有相同颜色的糖果
                t[c] = !t[c];
                now = max(now, work(num - 1) + 1); // 配对成功，篮子糖果数减一，答案加一
                t[c] = !t[c];
            } else {
                t[c] = !t[c];
                now = max(now, work(num + 1)); // 未配对成功，篮子糖果数加一
                t[c] = !t[c];
            }
            top[i]--; // 记得减回
        }
    }
    return now; // 返回在 (top[1], top[2], top[3], top[4]) 下的最大值
}

int main() {
    while (scanf("%d", &n) == 1 && n) { // 读取输入，直到结束
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= 4; j++) {
                scanf("%d", &a[i][j]); // 读取第 i 层第 j 堆的糖果颜色
            }
        }
        memset(f, -1, sizeof(f)); // 初始化 f 数组，-1 表示未计算过
        memset(top, 0, sizeof(top)); // 初始化 top 数组
        memset(t, 0, sizeof(t)); // 初始化 t 数组
        printf("%d\n", work(0)); // 初始篮子里的糖果数为 0，调用 work 函数计算结果
    }
    return 0;
}
