#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

const int INF = 1e9;
int f[105][105];
string s;

void write(int i, int j) {
    if (i == j) {
        if (s[i] == '(' || s[i] == ')') cout << "()";
        else cout << "[]";
    } else if (((s[i] == '(' && s[j] == ')') || (s[i] == '[' && s[j] == ']')) && f[i][j] == f[i + 1][j - 1]) {
        cout << s[i];
        write(i + 1, j - 1);
        cout << s[j];
    } else {
        for (int p = i; p < j; ++p) {
            if (f[i][j] == f[i][p] + f[p + 1][j]) {
                write(i, p);
                write(p + 1, j);
                return;
            }
        }
    }
}

int main() {
    int t;
    cin >> t;
    cin.ignore();

    while (t--) {
        getline(cin, s);
        getline(cin, s);  // read the actual input line

        int n = s.size();
        for (int i = 0; i < n; ++i) {
            f[i][i] = 1;
            if (i + 1 < n) f[i + 1][i] = 0;
        }

        for (int k = 1; k <= n; ++k) {
            for (int i = 0; i + k <= n; ++i) {
                int j = i + k - 1;
                f[i][j] = INF;

                if ((s[i] == '(' && s[j] == ')') || (s[i] == '[' && s[j] == ']')) {
                    f[i][j] = min(f[i][j], f[i + 1][j - 1]);
                } else if (s[i] == '(' || s[i] == '[') {
                    f[i][j] = min(f[i][j], f[i + 1][j] + 1);
                } else if (s[j] == ')' || s[j] == ']') {
                    f[i][j] = min(f[i][j], f[i][j - 1] + 1);
                }

                for (int p = i; p < j; ++p) {
                    f[i][j] = min(f[i][j], f[i][p] + f[p + 1][j]);
                }
            }
        }

        write(0, n - 1);
        cout << endl;
        if (t) cout << endl;
    }

    return 0;
}
