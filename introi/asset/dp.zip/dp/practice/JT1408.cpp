#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
using namespace std;
const int maxn = 1005;
struct Rect{
    int len,wid;
}rec[maxn];
int dismx[maxn],edge[maxn][maxn];
 
// is a inside b?
int inside(Rect a, Rect b){
  // 情况1: 保持原样(original)
  bool orig = (a.len < b.len) && (a.wid < b.wid); 
  // 情况2: 旋转90°(rotation)
  bool rot = (a.len < b.wid) && (a.wid < b.len);
  return orig || rot;
}

void addedge(int N){
  for (int i = 0;i < N;i++){
    for (int j =0 ;j < N;j++){
      if (inside(rec[i], rec[j]))   edge[i][j] = 1;
    }
  }
}
 
int solve(int i,int N){
    int &ans = dismx[i];
    // 已经计算过了
    if (ans > 0) return ans;
    // 否则根据递归的情况计算
    ans = 1;
    for (int j = 0;j < N;j++)
      if (edge[i][j])
        ans = max(ans,solve(j,N) + 1);
    return ans;
}
 
int main(){
    int T,N,x,y;
    scanf("%d",&T);
    while (T--){
      // 多测要清空!
      memset(dismx,0,sizeof(dismx));
      memset(edge,0,sizeof(edge));
      int tmp,res = 0;
      scanf("%d",&N);
      for (int i = 0;i < N;i++){
        scanf("%d%d",&x,&y);
        rec[i].len = x;
        rec[i].wid = y;
      }
      addedge(N);
      for (int i = 0;i < N;i++){
        tmp = solve(i,N);
        res = tmp>res?tmp:res;
      }
      printf("%d\n",res);
  }
    return 0;
}