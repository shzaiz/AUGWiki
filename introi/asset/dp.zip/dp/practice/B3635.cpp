#ifdef basic
#include <iostream>
#include <algorithm>
#include <climits>
using namespace std;

const int MAXN = 1000005; 
int dp[MAXN + 1];

int main() {
    int n;
    cin >> n;

    // 初始化 dp 数组
    dp[0] = 0; // 凑出 0 元需要 0 个硬币
    for (int i = 1; i <= n; ++i) {
        dp[i] = INT_MAX; // 初始化为一个较大的值，表示尚未计算出最优解
        if (i >= 1) dp[i] = min(dp[i], dp[i - 1] + 1);
        if (i >= 5) dp[i] = min(dp[i], dp[i - 5] + 1);
        if (i >= 11) dp[i] = min(dp[i], dp[i - 11] + 1);
    }

    cout << dp[n] << endl;
    return 0;
}
#else
#include <iostream>
#include <vector>
#include <climits>
#include <unordered_map>
using namespace std;

// 定义一个缓存，用于记忆化搜索
unordered_map<int, int> memo;

// DFS函数，返回凑出n元需要的最少硬币数量
int dfs(int n) {
    if (n == 0) return 0; // 基本情况
    if (n < 0) return INT_MAX; // 无法凑出负数元，返回一个很大的值
    if (memo.find(n) != memo.end()) return memo[n]; // 如果已经计算过，直接返回

    int res = INT_MAX;

    // 尝试使用面值为1、5、11的硬币
    int coin1 = dfs(n - 1);
    if (coin1 != INT_MAX) res = min(res, coin1 + 1);

    int coin5 = dfs(n - 5);
    if (coin5 != INT_MAX) res = min(res, coin5 + 1);

    int coin11 = dfs(n - 11);
    if (coin11 != INT_MAX) res = min(res, coin11 + 1);

    // 记忆化存储结果
    memo[n] = res;
    return res;
}

int main() {
    int n;
    cin >> n;

    int result = dfs(n);
    if (result == INT_MAX) {
        cout << -1 << endl; // 如果无法凑出，输出-1
    } else {
        cout << result << endl;
    }

    return 0;
}

#endif