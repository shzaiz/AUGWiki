#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <cstring>
using namespace std;

const int MAXN = 105;
int matrix[MAXN][MAXN];
int dp[MAXN][MAXN];
int R, C;

// 方向数组，上下左右
int dx[4] = {-1, 1, 0, 0};
int dy[4] = {0, 0, -1, 1};

int dfs(int x, int y) {
    if (dp[x][y] != -1) {
        return dp[x][y];
    }
    int maxLength = 1; // 每个位置最短路径长度至少为1
    for (int i = 0; i < 4; ++i) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (nx >= 0 && nx < R && ny >= 0 && ny < C && matrix[nx][ny] < matrix[x][y]) {
            maxLength = max(maxLength, 1 + dfs(nx, ny));
        }
    }
    dp[x][y] = maxLength;
    return dp[x][y];
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N;
    cin >> N;
    while (N--) {
        string name;
        cin >> name >> R >> C;
        
        for (int i = 0; i < R; ++i) {
            for (int j = 0; j < C; ++j) {
                cin >> matrix[i][j];
            }
        }

        memset(dp, -1, sizeof(dp));

        int longestPath = 0;
        for (int i = 0; i < R; ++i) {
            for (int j = 0; j < C; ++j) {
                longestPath = max(longestPath, dfs(i, j));
            }
        }

        cout << name << ": " << longestPath << endl;
    }

    return 0;
}
