#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 55;
int n, m;
int a[N][N];
int f[N][N][N][N];
const int dx[] = {1, 0}, dy[] = {0, 1};
int search (int x1, int y1, int x2, int y2) {
    if (x1 > n || x2 > n || y1 > m || y2 > m)
        return -2147483647;
    if (x1 == n && y1 == m && x2 == n && y2 == m)
        return 0;
    if (f[x1][y1][x2][y2] != -1)
        return f[x1][y1][x2][y2];
    int res = 0;
    for (int i = 0; i < 2; i ++) {
        for (int j = 0; j < 2; j ++) {
            res = max (res, search (x1 + dx[i], y1 + dy[i], x2 + dx[j], y2 + dy[j]));
        }
    }
    res += a[x1][y1];
    if (x1 != x2 || y1 != y2)
        res += a[x2][y2];
    return f[x1][y1][x2][y2] = res;
}
int main () {
    memset (f, -1, sizeof(f));
    scanf ("%d%d", &n, &m);
    for (int i = 1; i <= n; i ++) {
        for (int j = 1; j <= m; j ++) {
            scanf ("%d", &a[i][j]);
        }
    }
    int ans = search (1, 1, 1, 1);
    printf ("%d", ans);
}