#include <iostream>
#include <algorithm>
#include <climits>
#include <cstring>

using namespace std;

#define LEFT 1
#define RIGHT 0

const int MAXN = 205;
const int INF = INT_MAX / 3;

int n, num, m1, m2, tottime, sx;
// dp[i][j]:=在时间i, 车站j, 我还要等的最小时间 
int dp[MAXN][MAXN];

int t[MAXN], // t[i]:=地铁站间行驶时间从i到i+1
    d[MAXN], // d[i]:=往右开的第i辆车的出发时间
    e[MAXN]; // e[i]:=往左开的第i辆车的出发时间
bool hastrain[MAXN][MAXN][2]; // hastrain[i][j][LEFT/RIGHT]表示在时间i, 站点j, 是否有往LEFT/RIGHT开的车

int min(int o1, int o2) {
    return (o1 < o2) ? o1 : o2;
}

int main() {
    cin >> n;
    num = 1;

    while (n != 0) {
        for (int i = 0; i <= 200; ++i)
            for (int j = 0; j <= 200; ++j)
                dp[i][j] = INF;

        memset(hastrain, 0, sizeof(hastrain));
        memset(t, 0, sizeof(t));
        memset(d, 0, sizeof(d));
        memset(e, 0, sizeof(e));

        cin >> tottime;

        for (int i = 1; i < n; ++i)
            cin >> t[i];

        cin >> m1;
        for (int i = 1; i <= m1; ++i)
            cin >> d[i];

        cin >> m2;
        for (int i = 1; i <= m2; ++i)
            cin >> e[i];

        for (int i = 1; i <= m1; ++i) {
            int k = 1;
            int j = d[i];
            while (j <= tottime) {
                hastrain[j][k][LEFT] = true;
                ++k;
                if (k > n) break;
                j += t[k - 1];
            }
        }

        for (int i = 1; i <= m2; ++i) {
            int k = n;
            int j = e[i];
            while (j <= tottime) {
                hastrain[j][k][RIGHT] = true;
                --k;
                if (k == 0) break;
                j += t[k];
            }
        }

        dp[0][1] = 0;

        for (int i = 1; i <= tottime; ++i)
            for (int j = 1; j <= n; ++j) {
                dp[i][j] = min(dp[i][j], dp[i - 1][j] + 1);
                if (hastrain[i][j][LEFT]) dp[i][j] = min(dp[i][j], dp[i - t[j - 1]][j - 1]);
                if (hastrain[i][j][RIGHT]) dp[i][j] = min(dp[i][j], dp[i - t[j]][j + 1]);
            }

        if (dp[tottime][n] == INF)
            cout << "Case Number " << num << ": impossible" << endl;
        else
            cout << "Case Number " << num << ": " << dp[tottime][n] << endl;

        cin >> n;
        ++num;
    }

    return 0;
}
