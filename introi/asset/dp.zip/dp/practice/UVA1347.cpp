#include <iostream>
#include <cmath>
#include <iomanip>
#include <algorithm>

using namespace std;

const int MAXN = 1000;
int a[MAXN + 1], b[MAXN + 1];
double f[MAXN + 1][MAXN + 1], e[MAXN + 1][MAXN + 1];

int main() {
    int n;
    while (cin >> n) {
        
        if (n == 0) break;

        for (int i = 1; i <= n; ++i) {
            cin >> a[i] >> b[i];
        }

        // 初始化数组
        for (int i = 0; i <= n; ++i) {
            for (int j = 0; j <= n; ++j) {
                f[i][j] = 0.0;
                e[i][j] = 0.0;
            }
        }

        // 计算Euclid距离
        for (int i = 1; i <= n; ++i) {
            for (int j = 1; j <= n; ++j) {
                f[i][j] = sqrt(pow(a[i] - a[j], 2) + pow(b[i] - b[j], 2));
            }
        }

        // 计算动态规划数组
        for (int i = n - 1; i >= 2; --i) {
            for (int j = 1; j <= i; ++j) {
                if (i == n - 1) {
                    e[i][j] = f[i][n] + f[j][n];
                } else {
                    e[i][j] = min(f[i][i + 1] + e[i + 1][j], f[i + 1][j] + e[i + 1][i]);
                }
            }
        }

        // 输出结果
        cout << fixed << setprecision(2) << e[2][1] + f[2][1] << endl;
    }

    return 0;
}
