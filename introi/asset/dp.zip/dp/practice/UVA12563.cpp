#include <iostream>
#include <cstring>
#include <algorithm>

using namespace std;

const int MAXN = 100000;
int dp[MAXN];
int n, t, m, itemWeight;

int main() {
    cin >> n;
    for (int caseNum = 1; caseNum <= n; ++caseNum) {
        memset(dp, -0x3f, sizeof(dp));  // 初始化dp数组为极小值
        cin >> m >> t;
        dp[0] = 0;

        for (int j = 1; j <= m; ++j) {
            cin >> itemWeight;
            for (int k = t - 1; k >= itemWeight; --k) {
                dp[k] = max(dp[k], dp[k - itemWeight] + 1);
            }
        }

        int maxIndex = 0;
        for (int j = t - 1; j >= 0; --j) {
            if (dp[j] > dp[maxIndex]) {
                maxIndex = j;
            }
        }

        cout << "Case " << caseNum << ": " << dp[maxIndex] + 1 << " " << maxIndex + 678 << endl;
    }

    return 0;
}
