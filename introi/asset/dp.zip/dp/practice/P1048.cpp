#include<bits/stdc++.h>
using namespace std;
int T,M,t[105],w[105],dp[1005]; 
int main(){
	cin>>T>>M;
	for(int i=1;i<=M;i++){
		cin>>t[i]>>w[i];
	}
	for(int i=1;i<=M;i++)
		for(int j=T;j>=w[i];j--)
			dp[j] = max(dp[j], dp[j-t[i]]+w[i]);
	cout<<dp[T];

	return 0;
}
