#include <stdio.h>
#include <string.h>

#define MAX_CARDS 9
#define MAX_LAYERS 4
#define MAX_STATE 1953125  // 5^9 = 1953125

double dp_result[MAX_STATE];  // 存储每种情况的胜率
int dp_visited[MAX_STATE];  // 标记每种情况是否已计算
char Card[MAX_CARDS][MAX_LAYERS][3];  // 牌堆

int getIndex(int cnt[]) {
    int index = 0;
    int factor = 1;
    for (int i = 0; i < MAX_CARDS; ++i) {
        index += cnt[i] * factor;
        factor *= 5;  // 每个堆最大有 5 张牌
    }
    return index;
}

double DP(int cnt[], int c) {
    if (c == 0) {
        return 1.0;
    }

    int index = getIndex(cnt);
    if (dp_visited[index]) {
        return dp_result[index];
    }

    dp_visited[index] = 1;

    double Sum = 0.0;
    int Tot = 0;
    for (int i = 0; i < MAX_CARDS; ++i) {
        if (cnt[i] > 0) {
            for (int j = i + 1; j < MAX_CARDS; ++j) {
                if (cnt[j] > 0) {
                    if (Card[i][cnt[i] - 1][0] == Card[j][cnt[j] - 1][0]) {
                        ++Tot;
                        --cnt[i];
                        --cnt[j];

                        Sum += DP(cnt, c - 2);

                        ++cnt[i];
                        ++cnt[j];
                    }
                }
            }
        }
    }

    if (Tot == 0) {
        return dp_result[index] = 0;
    } else {
        return dp_result[index] = Sum / Tot;
    }
}

int Read() {
    for (int i = 0; i < MAX_CARDS; ++i) {
        for (int j = 0; j < MAX_LAYERS; ++j) {
            if (scanf("%s", Card[i][j]) != 1) {
                return 0;
            }
        }
    }
    return 1;
}

int main() {
    while (Read()) {
        int cnt[MAX_CARDS];
        for (int i = 0; i < MAX_CARDS; ++i) {
            cnt[i] = 4;
        }
        memset(dp_result, 0, sizeof(dp_result));
        memset(dp_visited, 0, sizeof(dp_visited));
        printf("%.6lf\n", DP(cnt, 36));
    }
    return 0;
}
