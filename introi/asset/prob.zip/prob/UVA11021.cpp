#include <iostream>
#include <cstdio>
using namespace std;

const int maxn = 1010;
int n, m, k;
double p[maxn], con[maxn];

double qpow(double x, int y) {
    double ans = 1;
    while (y) {
        if (y & 1) {
            ans *= x;
        }
        x *= x;
        y >>= 1;
    }
    return ans;
}

int main() {
    int T;
    cin >> T;
    for (int t = 1; t <= T; ++t) {
        cin >> n >> k >> m;
        for (int i = 0; i < n; ++i) {
            cin >> p[i];
        }
        con[0] = 0;
        con[1] = p[0];  
        for (int i = 2; i <= m; ++i) {
            con[i] = p[0];
            for (int j = 1; j < n; ++j) {
                con[i] += p[j] * qpow(con[i - 1], j);
            }
        }
        printf("Case #%d: %.6lf\n", t, qpow(con[m], k));
    }
    return 0;
}
