#include <iostream>
#include <cstdio>

using namespace std;

int main() {
    double a, b, c;

    while (scanf("%lf %lf %lf", &a, &b, &c) != EOF) {
        double result = (b * (b - 1 + a)) / ((a + b) * (a + b - c - 1));
        printf("%.5lf\n", result);
    }

    return 0;
}
