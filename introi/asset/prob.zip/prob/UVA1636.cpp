#include <iostream>
#include <string>

using namespace std;

int main() {
    string s;

    while (cin >> s) {
        int count_0 = 0;  // 记录 '0' 的个数
        int count_01 = 0; // 记录 "01" 的个数

        int n = s.length();

        // 统计 '0' 的个数和 "01" 的个数
        for (int i = 0; i < n; ++i) {
            if (s[i] == '0') {
                ++count_0;
                // 检查当前 '0' 和下一个字符是否构成 "01"
                if (s[(i + 1) % n] == '1') {
                    ++count_01;
                }
            }
        }

        int count_1 = n - count_0; // 计算 '1' 的个数

        // 判断并输出结果
        if (count_01 * n < count_0 * count_1) {
            cout << "SHOOT" << endl;
        } else if (count_01 * n == count_0 * count_1) {
            cout << "EQUAL" << endl;
        } else {
            cout << "ROTATE" << endl;
        }
    }

    return 0;
}
