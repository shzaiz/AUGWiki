#include <bits/stdc++.h>
using namespace std;

inline int read() {
    int ret = 0, f = 1;
    char ch = getchar();
    while (ch > '9' || ch < '0') {
        if (ch == '-') f = -1;
        ch = getchar();
    }
    while (ch >= '0' && ch <= '9') {
        ret = (ret << 1) + (ret << 3) + ch - '0';
        ch = getchar();
    }
    return ret * f;
}

int n;
long long numerator, denominator;

int main() {
    while (scanf("%d", &n) != EOF) {
        numerator = 1;
        denominator = 1;
        for (int i = 2; i <= n; i++) {
            numerator = numerator * i + denominator;
            denominator *= i;
            long long fac = __gcd(numerator, denominator);
            numerator /= fac;
            denominator /= fac;
        }
        numerator *= n;
        long long fac = __gcd(numerator, denominator);
        numerator /= fac;
        denominator /= fac;

        if (denominator == 1) {
            printf("%lld\n", numerator);
        } else {
            long long integer = numerator / denominator;
            numerator %= denominator;
            
            string integer_str = to_string(integer);
            string numerator_str = to_string(numerator);
            string denominator_str = to_string(denominator);
            int len1 = integer_str.size();
            int len2 = denominator_str.size();

            printf("%*s%lld\n", len1 + 1, "", numerator);
            printf("%s ", integer_str.c_str());
            printf("%s\n", string(len2, '-').c_str());
            printf("%*s%lld\n", len1 + 1, "", denominator);
        }
    }
    return 0;
}
