#include <iostream>
#include <cstdio>
#include <vector>

using namespace std;

double p[23];
double pe;
int n, r;

// 用于计算P(E)
void dfs(int x, int d, double now) {
    if (d > r) return;  // 如果买东西的人超过了r就返回
    if (x == n + 1) {   // 如果遍历完所有人
        if (d == r) {   // 如果正好有r个人买东西
            pe += now;
        }
        return;
    }
    // 选择买
    dfs(x + 1, d + 1, now * p[x]);
    // 选择不买
    dfs(x + 1, d, now * (1 - p[x]));
}

// 用于计算P(E_i)
double pei;
void dfss(int x, int d, int i, double now) {
    if (d > r) return;
    if (x == n + 1) {
        if (d == r) {
            pei += now;
        }
        return;
    }
    if (x == i) { // 如果遍历到第i个人
        dfss(x + 1, d + 1, i, now * p[x]);  // 第i个人必须买
        return;
    }
    // 选择买
    dfss(x + 1, d + 1, i, now * p[x]);
    // 选择不买
    dfss(x + 1, d, i, now * (1 - p[x]));
}

int main() {
    ios::sync_with_stdio(false);
    int caseNumber = 0;

    while (cin >> n >> r) {
        if (n == 0) break;
        printf("Case %d:\n", ++caseNumber);

        for (int i = 1; i <= n; ++i) {
            cin >> p[i];
        }

        pe = 0;  // 重置pe
        dfs(1, 0, 1.0);

        for (int i = 1; i <= n; ++i) {
            pei = 0;  // 重置pei
            dfss(1, 0, i, 1.0);
            printf("%.6f\n", pei / pe);
        }
    }

    return 0;
}
