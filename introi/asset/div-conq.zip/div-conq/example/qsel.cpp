#include <iostream>
#include <vector>

using namespace std;

// 辅助函数，交换两个元素
void swap(int& a, int& b) {
    int temp = a;
    a = b;
    b = temp;
}

// 分区函数，选择最后一个元素作为基准
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; ++j) {
        if (arr[j] <= pivot) {
            ++i;
            swap(arr[i], arr[j]);
        }
    }
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// QuickSelect函数
int quickSelect(vector<int>& arr, int low, int high, int k) {
    if (low <= high) {
        int pi = partition(arr, low, high);

        if (pi == k) {
            return arr[pi];
        } else if (pi > k) {
            return quickSelect(arr, low, pi - 1, k);
        } else {
            return quickSelect(arr, pi + 1, high, k);
        }
    }
    return -1; // 返回-1表示输入无效
}

int main() {
    vector<int> arr = {10, 4, 5, 8, 6, 11, 26};
    int k = 3; // 查找第k小的元素，这里k从0开始计数，即第k小元素是数组中第k+1小的元素

    if (k >= 0 && k < arr.size()) {
        int result = quickSelect(arr, 0, arr.size() - 1, k);
        cout << "The " << k + 1 << "th smallest element is " << result << endl;
    } else {
        cout << "Invalid input for k." << endl;
    }

    return 0;
}
