#include <iostream>
#include <algorithm>

using namespace std;

int n, m;
int pl[100005];

bool check(int x) {
    int num = 1, last_position = pl[1]; 
    for (int i = 2; i <= n; i++) {
        if (pl[i] - last_position >= x) {
            last_position = pl[i];
            num++;
        }
    }
    return num >= m;
}


int main() {
    cin >> n >> m;
    for (int i = 1; i <= n; i++) {
        cin >> pl[i];
    }
    sort(pl + 1, pl + n + 1);
    int l = 1, r = 1e9, ans = 0, mid;
    while (l < r) {
        mid = l + (r - l) / 2;
        if (check(mid)) {
            ans = mid;
            l = mid + 1;
        } else {
            r = mid;
        }
    }
    cout << ans << endl;
    return 0;
}
