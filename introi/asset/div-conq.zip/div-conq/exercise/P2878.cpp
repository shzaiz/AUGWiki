#include <bits/stdc++.h>
using namespace std;
#define N 100010
// BAD PRACTICE! DON'T DEFINE LIKE THIS!
#define int unsigned long long
struct C{
    int id,t,d;
}a[N];
int n,ans,S;
bool cmp(C x, C y){
    return x.t*y.d<x.d*y.t;
}
signed main(){
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i].t;
        cin>>a[i].d;
        S+=a[i].d;
    }
    sort(a+1,a+1+n,cmp);
    for(int i=1;i<=n;i++){
        S-=a[i].d;
        ans+=2*S*a[i].t;
    }
    cout<<ans;
    return 0;
}