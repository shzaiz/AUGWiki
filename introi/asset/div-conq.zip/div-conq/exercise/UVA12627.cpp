#include <iostream>
#include <cstdio>

#define MAXSIZE 31

using namespace std;
typedef long long ll;

int t, k, a, b;
ll allRed[MAXSIZE];

// 预处理出 30h 的所有红气球数
void init() {
    ll sum = 1;
    for (int i = 0; i < MAXSIZE; ++i) {
        allRed[i] = sum;
        sum *= 3;
    }
}

// 计算 k 小时 [1, i] 行的红气球数
ll cal(int k, int i) {
    if (i <= 0) return 0;
    if (k == 0) return 1;
    if (i <= (1 << (k - 1))) {
        return cal(k - 1, i) * 2;
    } else {
        return cal(k - 1, i - (1 << (k - 1))) + 2 * allRed[k - 1];
    }
}

int main() {
    init();

    scanf("%d", &t);
    for (int i = 1; i <= t; ++i) {
        scanf("%d%d%d", &k, &a, &b);
        ll up = cal(k, a - 1);
        ll down = cal(k, b);
        printf("Case %d: %lld\n", i, down - up);
    }

    return 0;
}
