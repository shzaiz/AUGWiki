#include <iostream>
#include <vector>
#include <cstring>

using namespace std;

const int MAXN = 10010;
vector<int> graph[MAXN];
bool visited[MAXN];
bool on_stack[MAXN];  // 用于检测环

void add_edge(int a, int b) {
    graph[a].push_back(b);
}

bool dfs(int v) {
    visited[v] = true;
    on_stack[v] = true;
    for (int u : graph[v]) {
        if (!visited[u]) {
            if (dfs(u)) {
                return true;  // 如果找到环，直接返回
            }
        } else if (on_stack[u]) {
            return true;  // 检测到环
        }
    }
    on_stack[v] = false;
    return false;
}

bool has_cycle(int n) {
    memset(visited, 0, sizeof(visited));
    memset(on_stack, 0, sizeof(on_stack));
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            if (dfs(i)) {
                return true;  // 找到环
            }
        }
    }
    return false;
}

int main() {
    int n, m;  // n是节点数，m是边数
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        add_edge(u, v);
    }

    if (has_cycle(n)) {
        cout << "YES" << endl;
    } else {
        cout << "NO" << endl;
    }

    return 0;
}
