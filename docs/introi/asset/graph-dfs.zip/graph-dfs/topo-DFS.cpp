#include <iostream>
#include <vector>
#include <stack>
#include <cstring>

using namespace std;

const int MAXN = 10010;
vector<int> graph[MAXN];
bool visited[MAXN];
stack<int> topological_order;

void add_edge(int a, int b) {
    graph[a].push_back(b);
}

void dfs(int v) {
    visited[v] = true;
    for (int u : graph[v]) {
        if (!visited[u]) {
            dfs(u);
        }
    }
    topological_order.push(v);
}

void topological_sort(int n) {
    memset(visited, 0, sizeof(visited));
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs(i);
        }
    }
}

int main() {
    int n, m; // n是节点数，m是边数
    cin >> n >> m;
    for (int i = 0; i < m; ++i) {
        int u, v;
        cin >> u >> v;
        add_edge(u, v);
    }

    topological_sort(n);

    // 输出拓扑排序结果
    while (!topological_order.empty()) {
        cout << topological_order.top() << " ";
        topological_order.pop();
    }
    cout << endl;

    return 0;
}
