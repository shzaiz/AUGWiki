#include <bits/stdc++.h>
using namespace std;
int g[55][55],d[55];
void euler(int u){
	for(int v=1;v<=50;v++){
		if(g[u][v]) {
			g[u][v]--;
			g[v][u]--;
			euler(v);
			cout<<v<<" "<<u<<endl;
		}
	}
}

int main(){
	int t,n;
	cin>>t;
	for(int k=1;k<=t;k++){
		cin>>n;
		memset(g,0,sizeof g);
		memset(d,0,sizeof d);
		for(int i=1;i<=n;i++){
			int u,v;
			cin>>u>>v;
			g[u][v]++;g[v][u]++;
			d[u]++;d[v]++;
		}
		cout<<"Case #"<<k<<endl;
		int i;
		for(i=1;i<=50;i++){
			if(d[i]%2) break;
		}
		if(i<=50) cout<<"some beads may be lost";
		else{
			for(int i=1;i<=50;i++) euler(i);
		}
		if(k!=t) cout<<"\n";
	}
} 