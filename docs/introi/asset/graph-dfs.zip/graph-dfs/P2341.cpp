#include <bits/stdc++.h>
using namespace std;

const int MAXN = 100010;
int m, n, scc_count, superstar_count;
int head[MAXN], reverse_head[MAXN], tot, reverse_tot;
int to[MAXN], reverse_to[MAXN], nxt[MAXN], reverse_nxt[MAXN];
vector<int> post_order;
bool visited[MAXN];
int component[MAXN];

void add_edge(int a, int b) {
    to[++tot] = b;
    nxt[tot] = head[a];
    head[a] = tot;

    reverse_to[++reverse_tot] = a;
    reverse_nxt[reverse_tot] = reverse_head[b];
    reverse_head[b] = reverse_tot;
}

void dfs(int v) {
    visited[v] = true;
    for (int i = head[v]; i; i = nxt[i]) {
        int u = to[i];
        if (!visited[u]) {
            dfs(u);
        }
    }
    post_order.push_back(v);
}

void rdfs(int v, int k) {
    visited[v] = true;
    component[v] = k;
    for (int i = reverse_head[v]; i; i = reverse_nxt[i]) {
        int u = reverse_to[i];
        if (!visited[u]) {
            rdfs(u, k);
        }
    }
}

int find_scc() {
    memset(visited, 0, sizeof(visited));
    post_order.clear();
    
    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            dfs(i);
        }
    }
    
    memset(visited, 0, sizeof(visited));
    int k = 0;
    for (int i = post_order.size() - 1; i >= 0; --i) {
        if (!visited[post_order[i]]) {
            rdfs(post_order[i], k++);
        }
    }
    return k;
}

void check_reachability(int v) {
    visited[v] = true;
    for (int i = reverse_head[v]; i; i = reverse_nxt[i]) {
        int u = reverse_to[i];
        if (!visited[u]) {
            check_reachability(u);
        }
    }
}

int main() {
    cin >> n >> m;
    memset(head, 0, sizeof(head));
    memset(reverse_head, 0, sizeof(reverse_head));
    tot = reverse_tot = 0;
    
    for (int i = 0; i < m; ++i) {
        int u, p;
        cin >> u >> p;
        add_edge(u, p);
    }

    int total_scc = find_scc();
    int last_scc = total_scc - 1;
    int star_node = -1;
    superstar_count = 0;

    for (int i = 1; i <= n; ++i) {
        if (component[i] == last_scc) {
            star_node = i;
            ++superstar_count;
        }
    }

    memset(visited, 0, sizeof(visited));
    rdfs(star_node, 1);

    for (int i = 1; i <= n; ++i) {
        if (!visited[i]) {
            cout << 0 << endl;
            return 0;
        }
    }

    cout << superstar_count << endl;
    return 0;
}
