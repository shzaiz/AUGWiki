#include <bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	int n,k,ans=0; cin>>n>>k;
	ans += n*k;	
	for(int l=1,r;l<=n;l = r+1){
		int t = k/l;
		r = (t)? min(k/t,n):n;
		ans -= t*(r-l+1)*(l+r)>>1;
	}
	cout<<ans;
	return 0;
}