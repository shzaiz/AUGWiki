#include <unordered_map>
#include <cstdio>
#include <algorithm>
#include <vector>

using namespace std;

int gcd(int a, int b) {
    while (b) {
        a %= b;
        swap(a, b);
    }
    return a;
}

int main() {
    int n, cnt = 0, ans = 0;
    scanf("%d", &n);

    vector<int> num(n * n);
    vector<int> a(n);
    unordered_map<int, int> mp;

    for (int i = 0; i < n * n; i++) {
        int x;
        scanf("%d", &x);
        mp[x]++;
        if (mp[x] == 1) num[cnt++] = x;  // Store the number if seen for the first time
    }

    num.resize(cnt);  // Resize to the actual number of unique elements
    sort(num.begin(), num.end(), greater<int>());

    for (int i = 0; i < cnt && ans < n; ) {
        if (mp[num[i]] == 0) {
            i++;
            continue;
        }

        a[ans++] = num[i];  // Store the largest available number
        mp[num[i]]--;

        for (int j = 0; j < ans - 1; j++) {
            mp[gcd(num[i], a[j])] -= 2;  // Remove gcd results from the map
        }
    }

    for (int i = 0; i < ans; i++) {
        printf("%d ", a[i]);
    }

    return 0;
}
