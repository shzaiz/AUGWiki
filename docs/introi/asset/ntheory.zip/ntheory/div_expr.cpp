#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>

using namespace std;

const int MAX_SIZE = 10001;
char inputStr[MAX_SIZE];
int numbers[MAX_SIZE];
int totalNumbers;

int gcd(int x, int y) {
    return x == 0 ? y : gcd(y % x, x);
}

bool judge(int* numbers, int totalNumbers) {
    numbers[2] /= gcd(numbers[2], numbers[1]);
    for (int i = 3; i <= totalNumbers; ++i) {
        numbers[2] /= gcd(numbers[2], numbers[i]);
    }
    return numbers[2] == 1;
}

int main() {

    while (scanf("%d", &numbers[1]) == 1) {
        char ch;
        totalNumbers = 1;

        while (scanf("%c", &ch) && ch == '/') {
            scanf("%d", &numbers[++totalNumbers]);
        }

        if (judge(numbers, totalNumbers)) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }

    return 0;
}
