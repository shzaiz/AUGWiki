#include <bits/stdc++.h>
using namespace std;
inline int read(){
	int x;
    x=0;char ch=0;bool sign=false;
    while(ch < '0' || ch > '9'){
        sign|=(ch == '-');
        ch=getchar();
    }
    while(!(ch < '0' || ch > '9')){
        x=x*10+(ch^48);
        ch=getchar();
    }
    x=sign ? -x : x;
    return x;
}

inline void print(int x){
    if(x<0)putchar('-'),x=-x;
    if(x>9)print(x/10);
    putchar(x%10+'0');
}
int phi[1000010],ans=0; 
void E(int n){
	for(int i=2;i<=n;i++) phi[i] = i;
	for(int i=2;i<=n;i++){
		if(phi[i]==i){
			for(int j=1;i*j<=n;j++){
				phi[i*j] = phi[i*j]/i*(i-1);
			}
		}
		
	}
}

int main(){
	int n = read();
	if(n==1) {
		print(0); return 0;
	}
	E(n);
	for(int i=2;i<n;i++) ans+= phi[i];
	ans = 3+2*ans;
	print(ans);
	return 0;
}