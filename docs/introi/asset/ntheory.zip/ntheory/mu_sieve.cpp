#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;

const int MAXN = 1000008;
int prime[MAXN], mu[MAXN], cnt = 0;
bool notp[MAXN];

int main() {
    int N=1e6;

    // Initialize the Möbius function array
    mu[1] = 1;

    // Sieve method to calculate the Möbius function for each number up to N
    for (int i = 2; i <= N; i++) {
        if (!notp[i]) {  // i is a prime number
            prime[++cnt] = i;
            mu[i] = -1;
        }
        for (int j = 1; j <= cnt && i * prime[j] <= N; j++) {
            notp[i * prime[j]] = true;

            if (i % prime[j] == 0) {
                mu[i * prime[j]] = 0;  // i * prime[j] has a squared prime factor
                break;
            } else {
                mu[i * prime[j]] = mu[i] * mu[prime[j]];  // Multiply by -1 for each distinct prime factor
            }
        }
    }

    // Print the calculated Möbius function values
    int n;
    while(cin>>n){
        cout<<mu[n]<<endl;
    }
    return 0;
}
