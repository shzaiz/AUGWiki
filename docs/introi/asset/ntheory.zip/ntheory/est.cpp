#ifdef false
const int maxn=2e6+6;
bool isprime[maxn+10]; // isprime[i] := 数字i是不是质数
void sieve(){
    memset(isprime,true,sizeof(isprime));
    isprime[0]=isprime[1]=false;
    for(int i=2;i<=maxn;i++){
        if (isprime[i]) {
            for (int j = i * i; j <= maxn; j += i) {
                isprime[j] = false;
            }
        }
    }
}
#endif

#include <iostream>
#include <string.h>
using namespace std;
#define MAXN 10010

bool isprime[MAXN]; // isprime[i]表示i是不是素数
int prime[MAXN]; // 现在已经筛出的素数列表
int n; // 上限，即筛出<=n的素数
int cnt; // 已经筛出的素数个数

void euler(){
    memset(isprime, true, sizeof(isprime)); // 先全部标记为素数
    isprime[1] = false; // 1不是素数
    // i从2循环到n 外层循环
    for(int i = 2; i <= n; ++i){ 
        if(isprime[i]) prime[++cnt] = i; // 如果i没有被前面的数筛掉，则i是素数
        for(int j = 1; j <= cnt && i * prime[j] <= n; ++j){ // j循环枚举现在已经筛出的素数（内层循环）
            // 筛掉i的素数倍，即i的prime[j]倍
            isprime[i * prime[j]] = false;
            // 倍数标记为合数，也就是i用prime[j]把i * prime[j]筛掉了
            if(i % prime[j] == 0) break;
        }
        
    }
}

int main(){
    n = 30;
    euler();
}

/**
for(int i=1; i<=n; i++){
            if(isprime[i]) cout<<i<<" ";
            else cout<<"X "<<" ";
        }
        cout<<"\n";
 */
