#include <cstdio>
#include <cstring>
#include <iostream>
using namespace std;
const int MAXN = 1000009;
int prime[MAXN], phi[MAXN], cnt = 0;
bool notp[MAXN];

int main() {
    int N=1e6;
    // Initialize the phi values
    phi[1] = 1;

    // Sieve method to calculate phi for every number up to N
    for (int i = 2; i <= N; i++) {
        if (!notp[i]) {  // i is a prime number
            prime[++cnt] = i;
            phi[i] = i - 1;
        }
        
        
        // Wrong! 
        // notp[i * prime[j]] = 1;
        // phi[i * prime[j]] = phi[i] * phi[prime[j]];
        // if (i % prime[j] == 0) {
        //     break;
        // }
        for (int j = 1; j <= cnt && i * prime[j] <= N; j++) {
            notp[i * prime[j]] = true;
            if (i % prime[j] == 0) {
                // If i is divisible by prime[j], then φ(i * prime[j]) = φ(i) * prime[j], and the loop breaks.
                phi[i * prime[j]] = phi[i] * prime[j];
                break;
            } else {
                // Otherwise, φ(i * prime[j]) = φ(i) * (prime[j] - 1).
                phi[i * prime[j]] = phi[i] * (prime[j] - 1);
            }
        }
        

    }

    while(cin>>N){
        cout<<phi[N]<<endl;
    }

    return 0;
}
