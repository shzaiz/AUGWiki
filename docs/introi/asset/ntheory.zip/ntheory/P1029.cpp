#include<bits/stdc++.h>
using namespace std;
int m,n,ans;
main(){
    cin>>m>>n;
    if(m==n)ans--;
    n*=m;
    for(int i=1;i<=sqrt(n);i++){
        if(n%i==0&&__gcd(i,n/i)==m) ans+=2;
    }
    cout<<ans;
}