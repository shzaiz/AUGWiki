#include <cstdio>
#include <cctype>
#include <tuple>
using namespace std;

const int MOD = 19260817;

inline int getint() {
    int res = 0, ch = getchar();
    while (!isdigit(ch) && ch != EOF)
        ch = getchar();
    while (isdigit(ch)) {
        res = (res << 3) + (res << 1) + (ch - '0');
        res %= MOD;
        ch = getchar();
    }
    return res;
}

int exgcd(int a, int b, int &x, int &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    int r = exgcd(b, a % b, x, y);
    tie(x, y) = make_tuple(y, x - (a / b) * y);
    return r;
}

int main() {
    int a, b;
    a = getint();
    b = getint();

    if (b == 0) {
        puts("Angry!");
        return 0;
    }

    int x, y;
    exgcd(b, MOD, x, y);
    x = (x % MOD + MOD) % MOD;
    printf("%lld\n", a * (long long)(x) % MOD);

    return 0;
}
