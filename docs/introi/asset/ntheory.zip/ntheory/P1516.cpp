/*
注意好如果有两个变量的话, 注意谁是定的, 谁是动的. 
 
还有注意最小正整数解的构造, 加的倍数是另一个来除. 
 
*/
 
#include <bits/stdc++.h>
using namespace std;
#define MAXN 100010
#define pb push_back
#define LL long long
#define INF 0x3f3f3f3f
#define DEBUG printf("Passing [%s] in LINE %d",__FUNCTION__,__LINE__)
#define fi first
#define se second
#define F(i,j,k) for(int i=j;i<=k;i++)
#define Fd(i,j,k) for(int i=j;i>=k;i--)
#define MOD 1000000007
void solve();
LL exgcd(LL a, LL b, LL &x, LL &y){
    if(a==0) {x=0,y=1;return b;}
    LL r = exgcd(b%a,a,x,y);
    tie(x,y) = make_tuple(y-(b/a)*x, x);
    return r;
}
 
LL gcd(LL a,LL b){
    if(b==0) return a;
    return gcd(b,a%b);
}
signed main(){
    /*
    k(n-m) + zL = (x-y)
    */
    setbuf(stdout, NULL);
    LL x,y,m,n,L;
    cin>>x>>y>>m>>n>>L;
    LL A=n-m, B=x-y;
    if(A<0){A=-A, B=-B;}
    int gc = gcd(A,L);
    if(B%gc!=0){
        printf("Impossible\n");
        return 0;
    }
     
    LL xx=-1, yy=-1; 
    LL res = exgcd(A,L,xx,yy);
    // printf("%d %d",xx,yy);
    printf("%lld",(xx*(B/gc)%(L/gc)+(L/gc))%(L/gc));
     
}