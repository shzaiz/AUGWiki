#include <bits/stdc++.h>
#define ll long long 
using namespace std;
ll pow(ll x,ll y, ll mod){
	x%=mod;
	ll ans=1;
	int base=1;
	for(;y;y>>=1,(x*=x)%mod)
		if(y&1) (ans *=x) % mod;
	return ans%mod;
}

int solve(int n,int p){
	return  pow(n, p - 2, p);
}

void Exgcd(ll a, ll b, ll &x, ll &y) {
    if (!b) x = 1, y = 0;
    else Exgcd(b, a % b, y, x), y -= a / b * x;
}

void sv2(){
	int n,p;
	scanf("%d %d",&n,&p);
	cout<<"1"<<endl;
	int inv[3000010];
	inv[1] = 1;
	for(int i=2;i<=n;i++){
		inv[i]=(ll)(p-p/i)*inv[p%i]%p;
		printf("%d\n",inv[i]);
	}
		
}

main(){
	ll x, y;
    Exgcd (a, p, x, y);
    x = (x % p + p) % p;
    printf ("%d\n", x); 
}