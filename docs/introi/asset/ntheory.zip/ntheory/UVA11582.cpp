#include <stdio.h>

typedef unsigned long long ull;
const size_t MAXN = 1000 * 1000 + 3;

ull qpow(ull a, ull b, ull mod) {
    a %= mod;
    ull ans = 1;
    while (b) {
        if (b & 1) {
            ans = ans * a % mod;
        }
        a = a * a % mod;
        b >>= 1;
    }
    return ans;
}

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        ull a, b, n;
        scanf("%llu%llu%llu", &a, &b, &n);
        
        ull f[MAXN];
        ull repeat = 0;

        f[0] = 0;
        f[1] = 1 % n;

        for (ull i = 2; i <= n * n + 1; ++i) {
            f[i] = (f[i - 1] + f[i - 2]) % n;
            if (f[i - 1] == f[0] && f[i] == f[1]) {
                repeat = i - 1;
                break;
            }
        }
        
        printf("%llu\n", f[qpow(a, b, repeat)]);
    }
    return 0;
}
