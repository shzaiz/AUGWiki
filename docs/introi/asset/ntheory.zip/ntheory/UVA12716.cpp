#ifdef TLE
#include <bits/stdc++.h>
using namespace std;

const int MAX_N = 3e7 + 10;
long long prefix_sum[MAX_N];

void calculate_prefix_sum(int n) {
    for (int d = 1; d <= n; ++d) {
        for (int i = d << 1; i <= n; i += d) {
            if (i >= (i ^ d) && __gcd(i, i ^ d) == d) {
                ++prefix_sum[i];
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        prefix_sum[i] += prefix_sum[i - 1];
    }
}

int main() {
    int max_value = 30000000;
    calculate_prefix_sum(max_value);

    int test_cases, n;
    cin >> test_cases;

    for (int i = 1; i <= test_cases; ++i) {
        scanf("%d", &n);
        printf("Case %d: %lld\n", i, prefix_sum[n]);
    }

    return 0;
}
#else 
#include <bits/stdc++.h>
using namespace std;

const int MAX_N = 3e7 + 10;
long long prefix_sum[MAX_N];

void calculate_prefix_sum(int n) {
    for (int d = 1; d <= n; ++d) {
        for (int i = d << 1; i <= n; i += d) {
            if ((i ^ (i - d)) == d) {
                ++prefix_sum[i];
            }
        }
    }

    for (int i = 1; i <= n; ++i) {
        prefix_sum[i] += prefix_sum[i - 1];
    }
}

int main() {
    int max_value = 30000000;
    calculate_prefix_sum(max_value);

    int test_cases, x;
    cin >> test_cases;

    for (int i = 1; i <= test_cases; ++i) {
        scanf("%d", &x);
        printf("Case %d: %lld\n", i, prefix_sum[x]);
    }

    return 0;
}
#endif