#include <bits/stdc++.h>
using namespace std;

const int MAX_N = 1e4 + 10;
int p, q, r, s;
int factors_count[MAX_N];
bool is_composite[MAX_N];
vector<int> primes;

void sieve() {
    for (int i = 2; i <= 10000; ++i) {
        if (!is_composite[i]) {
            primes.push_back(i);
            for (int j = i; j <= 10000; j += i) {
                is_composite[j] = true;
            }
        }
    }
}

void factorize(int n, int sign) {
    for (int i = 0; i < primes.size(); ++i) {
        while (n % primes[i] == 0) {
            n /= primes[i];
            factors_count[i] += sign;
        }
        if (n == 1) break;
    }
}

void add_factors(int n, int sign) {
    for (int i = 1; i <= n; ++i) {
        factorize(i, sign);
    }
}

int main() {
    sieve();
    while (scanf("%d%d%d%d", &p, &q, &r, &s) != EOF) {
        memset(factors_count, 0, sizeof(factors_count));
        
        add_factors(p, 1);
        add_factors(r - s, 1);
        add_factors(s, 1);
        add_factors(p - q, -1);
        add_factors(q, -1);
        add_factors(r, -1);
        
        double result = 1.0;
        for (int i = 0; i < primes.size(); ++i) {
            result *= pow(static_cast<double>(primes[i]), factors_count[i]);
        }
        
        printf("%.5f\n", result);
    }
    return 0;
}
