
#include <cstdio>
#include <vector>
#include <queue>
#include <cstring>

#define maxn 1001000
#define maxNodes 10000  // 定义一个足够大的数来容纳所有节点

using namespace std;

struct Node {
    bool have_value;
    int v;
    int left, right;
    Node() : have_value(false), left(-1), right(-1) {}
};

Node nodes[maxNodes];  // 用数组来存储节点
int nodeCount;  // 用来记录当前节点的数量
int v;
bool failed;
char s[maxn];
int root;

void reset_tree() {
    nodeCount = 0;
    root = nodeCount++;
    nodes[root] = Node();
}

void remove_tree() {
    // 数组无需手动释放内存，只需要重置
    reset_tree();
}

bool BFS(vector<int> &ans) {
    ans.clear();
    queue<int> Q;
    Q.push(root);
    while (!Q.empty()) {
        int u = Q.front();
        Q.pop();
        if (!nodes[u].have_value) {
            return false;
        }
        ans.push_back(nodes[u].v);
        if (nodes[u].left != -1) {
            Q.push(nodes[u].left);
        }
        if (nodes[u].right != -1) {
            Q.push(nodes[u].right);
        }
    }
    return true;
}

void addnode(int v, char *s) {
    int n = strlen(s);
    int u = root;
    for (int i = 0; i < n; i++) {
        if (s[i] == 'L') {
            if (nodes[u].left == -1) {
                nodes[u].left = nodeCount++;
                nodes[nodes[u].left] = Node();
            }
            u = nodes[u].left;
        }
        if (s[i] == 'R') {
            if (nodes[u].right == -1) {
                nodes[u].right = nodeCount++;
                nodes[nodes[u].right] = Node();
            }
            u = nodes[u].right;
        }
    }
    if (nodes[u].have_value) {
        failed = true;
    }
    nodes[u].v = v;
    nodes[u].have_value = true;
}

bool read_input() {
    failed = false;
    reset_tree();
    for (;;) {
        if (scanf("%s", s) != 1) {
            return false;
        }
        if (strcmp(s, "()") == 0) {
            break;
        }
        sscanf(&s[1], "%d", &v);
        addnode(v, strchr(s, ',') + 1);
    }
    return true;
}

int main() {
    vector<int> ans;
    while (read_input()) {
        if (failed || !BFS(ans)) {
            printf("not complete\n");
        } else {
            for (vector<int>::iterator t = ans.begin(); t != ans.end(); t++) {
                if (t != ans.end() - 1) {
                    printf("%d ", *t);
                } else {
                    printf("%d", *t);
                }
            }
            printf("\n");
        }
    }
    return 0;
}

#ifdef stillptr
// but static allocation
#include <cstdio>
#include <vector>
#include <queue>
#include <cstring>

#define maxn 1001000
#define maxNodes 10000  // 定义一个足够大的数来容纳所有节点

using namespace std;

struct Node {
    bool have_value;
    int v;
    Node *left, *right;
    Node() : have_value(false), left(NULL), right(NULL) {}
};

Node nodes[maxNodes];  // 用数组来存储节点
int nodeCount;  // 用来记录当前节点的数量
int v;
bool failed;
char s[maxn];
Node *root;

Node* newnode() {
    if (nodeCount >= maxNodes) {
        return NULL;
    }
    return &nodes[nodeCount++];
}

void reset_tree() {
    nodeCount = 0;
    root = newnode();
}

void remove_tree(Node *p) {
    // 数组无需手动释放内存，只需要重置
    reset_tree();
}

bool BFS(vector<int> &ans) {
    ans.clear();
    queue<Node*> Q;
    Q.push(root);
    while (!Q.empty()) {
        Node* u = Q.front();
        Q.pop();
        if (!u->have_value) {
            return false;
        }
        ans.push_back(u->v);
        if (u->left != NULL) {
            Q.push(u->left);
        }
        if (u->right != NULL) {
            Q.push(u->right);
        }
    }
    return true;
}

void addnode(int v, char *s) {
    int n = strlen(s);
    Node *u = root;
    for (int i = 0; i < n; i++) {
        if (s[i] == 'L') {
            if (u->left == NULL) {
                u->left = newnode();
            }
            u = u->left;
        }
        if (s[i] == 'R') {
            if (u->right == NULL) {
                u->right = newnode();
            }
            u = u->right;
        }
    }
    if (u->have_value) {
        failed = true;
    }
    u->v = v;
    u->have_value = true;
}

bool read_input() {
    failed = false;
    reset_tree();
    for (;;) {
        if (scanf("%s", s) != 1) {
            return false;
        }
        if (strcmp(s, "()") == 0) {
            break;
        }
        sscanf(&s[1], "%d", &v);
        addnode(v, strchr(s, ',') + 1);
    }
    return true;
}

int main() {
    vector<int> ans;
    while (read_input()) {
        if (failed || !BFS(ans)) {
            printf("not complete\n");
        } else {
            for (vector<int>::iterator t = ans.begin(); t != ans.end(); t++) {
                if (t != ans.end() - 1) {
                    printf("%d ", *t);
                } else {
                    printf("%d", *t);
                }
            }
            printf("\n");
        }
    }
    return 0;
}
#endif

#ifdef dynamicptr
// be careful, be careful, be careful you have fully understand
// syntax and semantics of pointers!
#include <cstdio>
#include <vector>
#include <queue>
#include <cstring>
#define maxn 1001000
using namespace std;
struct Node {
	bool have_value;
	int v;
	Node *left,*right;
	Node():have_value(false),left(NULL),right(NULL) {}
};
int v;
bool failed;
char s[maxn];
Node* root;
Node* newnode() {
	return new Node();
}
void remove_tree(Node *p) {
	if(p == NULL) {
		return ;
	}
	remove_tree(p->left);
	remove_tree(p->right);
	delete p;
}

bool BFS(vector<int> &ans) {
	ans.clear();
	queue<Node* > Q;
	Q.push(root);
	while(!Q.empty()) {
		Node* u=Q.front();
		Q.pop();
		if(!u->have_value) {
			return false;
		}
		ans.push_back(u->v);
		if(u->left != NULL) {
			Q.push(u->left);
		}
		if(u->right != NULL) {
			Q.push(u->right);
		}
	}
	return true;
}
void addnode(int v,char *s) {
	int n=strlen(s);
	Node *u=root;
	for(int i=0; i<n; i++) {
		if(s[i] == 'L') {
			if(u->left == NULL) {
				u->left=newnode();
			}
			u=u->left;
		}
		if(s[i] == 'R') {
			if(u->right == NULL) {
				u->right=newnode();
			}
			u=u->right;
		}
	}
	if(u->have_value) {
		failed=true;
	}
	u->v=v;
	u->have_value=true;
}

bool read_input() {
	failed=false;
	remove_tree(root);
	root=newnode();
	for( ;; ) {
		if(scanf("%s", s) != 1) {
			return false;
		}
		if(strcmp(s,"()") == 0) {
			break;
		}
		sscanf(&s[1],"%d",&v);
		addnode(v,strchr(s,',')+1);
	}
	return true;
}

int main() {
	vector<int> ans;
	while(read_input()) {
		if(failed || !BFS(ans)) {
			printf("not complete");
		} else {
			for(vector<int>::iterator t=ans.begin(); t!=ans.end(); t++) {
				if(t != ans.end()-1) {
					printf("%d ",*t);
				} else {
					printf("%d",*t);
				}
			}
		}
		printf("\n");
	}
	return 0;
}
#endif