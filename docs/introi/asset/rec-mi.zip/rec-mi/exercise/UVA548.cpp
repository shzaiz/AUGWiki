#include <bits/stdc++.h>

using namespace std;

const int maxNodes = 10000 + 10;  // 设置最大节点数
const int inf = 0x7fffffff;

struct Node {
    int v;
    Node *left, *right;
    Node() : v(0), left(nullptr), right(nullptr) {}
};  // 首先利用结构体构造树的节点

Node nodes[maxNodes];  // 预先分配节点数组
int nodeCount;
int p[maxNodes], i[maxNodes], n, b, best;

bool read(int *a) {
    string s;
    if (!getline(cin, s)) return false;  // 输入进树的节点数
    stringstream tf(s);
    int x;
    n = 0;
    while (tf >> x) a[n++] = x;
    return n > 0;
}

Node* newnode() {
    if (nodeCount >= maxNodes) {
        return nullptr;  // 超过最大节点数时返回空指针
    }
    return &nodes[nodeCount++];
}

Node* build(int l1, int r1, int l2, int r2) {
    if (l1 > r1) return nullptr;  // null == 空，所以空树返回空

    Node* t = newnode();  // 申请节点
    t->v = p[r2];  // 运用链表
    int pos = l1;
    while (i[pos] != t->v) pos++;  // 添加子树
    int cnt = pos - l1;
    t->left = build(l1, pos - 1, l2, l2 + cnt - 1);  // 使用数组索引代替指针
    t->right = build(pos + 1, r1, l2 + cnt, r2 - 1);  // 构造左右子树
    return t;
}

void dfs(Node* t, int sum) {
    if (t == nullptr) return;

    sum += t->v;
    if (t->left == nullptr && t->right == nullptr) {  // 检查是否为叶子节点
        if (sum < b || (sum == b && t->v < best)) {
            b = sum;
            best = t->v;
        }
    }
    if (t->left != nullptr) dfs(t->left, sum);
    if (t->right != nullptr) dfs(t->right, sum);  // 搜索回溯
}

int main() {
    while (read(i)) {  // 输入
        read(p);
        nodeCount = 0;
        b = inf;
        best = inf;
        Node* root = build(0, n - 1, 0, n - 1);
        dfs(root, 0);  // 从根节点开始搜
        printf("%d\n", best);
    }
    return 0;
}
