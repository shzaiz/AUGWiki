#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>

using namespace std;

const char COLORS[4] = {' ', 'R', 'G', 'B'}; // 表示 1, 2, 3 对应字母
int n;
int colorCount[4] = {0}; // 颜色计数
int indices[1005];       // 原始位置索引
char s[1005];            // 字符数组表示颜色

// 深度优先搜索函数
bool dfs(char s[]) {
    bool singleColorFound = false;

    // 查找是否有只出现一次的颜色
    for (int x = 1; x <= 3; x++) {
        if (colorCount[x] == 1) {
            singleColorFound = true;
            for (int i = 0; i < n; i++) {
                if (s[i] == COLORS[x]) {
                    // 输出所有可能的配对
                    for (int j = i + 2; 
                         j <= (i == 0 ? n - 2 : n - 1); 
                         j++) {
                        printf("%d %d\n", indices[i], indices[j]);
                    }
                    for (int j = i - 2; 
                         j >= (i == (n - 1) ? 1 : 0); 
                         j--) {
                        printf("%d %d\n", indices[i], indices[j]);
                    }
                    return true;
                }
            }
        }
    }

    if (!singleColorFound) {
        // 没有只出现一次的颜色，查找任意三个不同颜色的连续位置
        for (int i = 0; i < n - 3; i++) {
            if (s[i] != s[i + 1] && 
                s[i + 1] != s[i + 2] && 
                s[i] != s[i + 2]) {
                printf("%d %d\n", indices[i], indices[i + 2]);
                char removedColor = s[i + 1];
                for (int j = i + 1; j < n - 1; j++) {
                    s[j] = s[j + 1];
                    indices[j] = indices[j + 1];
                }
                s[n - 1] = '\0';
                n--; // 更新长度

                // 更新颜色计数
                if (removedColor == 'R') {
                    colorCount[1]--;
                } else if (removedColor == 'G') {
                    colorCount[2]--;
                } else {
                    colorCount[3]--;
                }
                break;
            }
        }
    }

    return dfs(s);
}

int main() {
    // 读入回车避免字符数组第一个元素为回车
    scanf("%d\n", &n);

    // 输入并统计数量
    for (int i = 0; i < n; i++) {
        scanf("%c", &s[i]);
        indices[i] = i + 1;
        if (s[i] == 'R') {
            colorCount[1]++;
        } else if (s[i] == 'G') {
            colorCount[2]++;
        } else {
            colorCount[3]++;
        }
    }

    // 检查是否所有颜色都至少有一个
    for (int i = 1; i <= 3; i++) {
        if (colorCount[i] == 0) {
            printf("0\n");
            return 0;
        }
    }

    printf("%d\n", n - 3); // 输出结果数量
    dfs(s);

    return 0;
}
