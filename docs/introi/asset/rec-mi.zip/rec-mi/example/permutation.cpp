#include <iostream>
using namespace std;

const int MAXN = 10;
int A[MAXN] = {0}; // 存放当前排列的数组
void print_permutation(int n, int* A, int cur) {
    // 递归边界：如果当前索引等于n，打印当前排列
    if (cur == n) {
        for (int i = 0; i < n; i++) {
            printf("%d ", A[i]);
        }
        printf("\n");
        return;
    }
    
    // 尝试在 A[cur] 中填各个整数 i
    for (int i = 1; i <= n; i++) {
        int ok = 1;
        
        // 检查 i 是否已经在 A[0] 到 A[cur-1] 中出现过
        for (int j = 0; j < cur; j++) {
            if (A[j] == i) {
                ok = 0;
                break;
            }
        }
        
        // 如果 i 没有出现过，选择 i 并递归填下一位
        if (ok) {
            A[cur] = i;
            print_permutation(n, A, cur + 1);
        }
    }
}

int main() {
    int n;
    cin >> n;
    for(int i=0; i<n; i++) cin>>A[i];
    
    print_permutation(n, A, 0);

    return 0;
}
