#include <iostream>
#include <string>
#include <unordered_set>

using namespace std;

// 模拟单词字典
unordered_set<string> dictionary = {"apple", "pen", "applepen", "pine", "pineapple"};

// 判断子字符串是否是一个有效单词
bool isWord(const string& str) {
    return dictionary.find(str) != dictionary.end();
}

// 判断字符串是否可以被分割成字典中的单词
bool Splittable(const string& A) {
    int n = A.size();
    if (n == 0) {
        return true;
    }

    for (int i = 1; i <= n; ++i) {
        if (isWord(A.substr(0, i))) {
            if (Splittable(A.substr(i))) {
                return true;
            }
        }
    }

    return false;
}

int main() {
    string input;
    cin >> input;

    if (Splittable(input)) {
        cout << "Yes" << endl;
    } else {
        cout << "No" << endl;
    }

    return 0;
}
