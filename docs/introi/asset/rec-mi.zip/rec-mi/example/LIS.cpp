#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

#ifdef take1
int LISBigger(int prev, const vector<int>& A, int start) {
    if (start == A.size()) {
        return 0;
    } else if (A[start] <= prev) {
        return LISBigger(prev, A, start + 1);
    } else {
        int skip = LISBigger(prev, A, start + 1);
        int take = LISBigger(A[start], A, start + 1) + 1;
        return max(skip, take);
    }
}


int main() {
    int n;
    cin >> n;

    vector<int> A(n);
    for (int i = 0; i < n; ++i) {
        cin >> A[i];
    }

    int result = LISBigger(INT_MIN, A, 0);
    cout << result << endl;

    return 0;
}
#endif

#ifdef idences
#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

// 函数声明
int LISBigger(const vector<int>& A, int i, int j, int n);

int main() {
    int n;
    cin >> n;

    vector<int> A(n);
    for (int k = 0; k < n; ++k) {
        cin >> A[k];
    }

    int i, j;
    cin >> i >> j;

    int result = LISBigger(A, i, j, n);
    cout<< result << endl;

    return 0;
}

int LISBigger(const vector<int>& A, int i, int j, int n) {
    if (j >= n) {
        return 0;
    } else if (A[i] >= A[j]) {
        return LISBigger(A, i, j + 1, n);
    } else {
        int skip = LISBigger(A, i, j + 1, n);
        int take = 1 + LISBigger(A, j, j + 1, n);
        return max(skip, take);
    }
}

#endif

#define take2
#ifdef take2
// 函数声明
int LISfirst(const vector<int>& A, int i);

int main() {
    int n;
    cin >> n;

    vector<int> A(n);
    for (int k = 0; k < n; ++k) {
        cin >> A[k];
    }

    int maxLength = 0;

    // 找到所有以A[i]开头的最长递增子序列
    for (int i = 0; i < n; ++i) {
        maxLength = max(maxLength, LISfirst(A, i));
    }

    cout <<  maxLength << endl;

    return 0;
}

int LISfirst(const vector<int>& A, int i) {
    int best = 0; // 初始化best为0

    for (int j = i + 1; j < A.size(); ++j) {
        if (A[j] > A[i]) {
            best = max(best, LISfirst(A, j));
        }
    }

    return 1 + best;
}

#endif