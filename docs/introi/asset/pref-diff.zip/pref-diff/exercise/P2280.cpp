#include <iostream>
#include <algorithm>

using namespace std;

const int MAXN = 5005;
int n, m;
int s[MAXN][MAXN];

// 读取输入并更新坐标系
void readInput() {
    cin >> n >> m;
    for (int i = 1; i <= n; ++i) {
        int x, y, v;
        cin >> x >> y >> v;
        s[x + 1][y + 1] += v; // 坐标范围变成 [1, 5001]，避免越界
    }
}

// 计算二维前缀和
void computePrefixSum() {
    for (int i = 1; i < MAXN; ++i) {
        for (int j = 1; j < MAXN; ++j) {
            s[i][j] = s[i - 1][j] + s[i][j - 1] - s[i - 1][j - 1] + s[i][j];
        }
    }
}

// 找出边长为 m 的正方形区域中目标价值的最大和
int findMaxSum() {
    int ans = 0;
    for (int i = m; i < MAXN; ++i) {
        for (int j = m; j < MAXN; ++j) {
            int num = s[i][j] - s[i - m][j] - s[i][j - m] + s[i - m][j - m];
            ans = max(ans, num);
        }
    }
    return ans;
}

int main() {
    readInput();
    computePrefixSum();
    int ans = findMaxSum();
    cout << ans << endl;
    return 0;
}
