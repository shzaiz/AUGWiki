import sympy as sp

# 定义符号变量
k = sp.symbols('k')
K = sp.FiniteSet(*range(1, 11))  # 这里假设 K 是 {1, 2, ..., 10}

# 定义函数 f 和 g
f = sp.Function('f')(k)
g = sp.Function('g')(k)

# 定义常数 c
c = sp.symbols('c')

# 性质 1: 常数项进出求和记号
sum1 = sp.Sum(c * f, (k, 1, 10))
sum1_out = c * sp.Sum(f, (k, 1, 10))

# 验证性质 1
assert sp.simplify(sum1) == sp.simplify(sum1_out)

# 性质 2: 求和记号的拆分
sum2 = sp.Sum(f + g, (k, 1, 10))
sum2_split = sp.Sum(f, (k, 1, 10)) + sp.Sum(g, (k, 1, 10))

# 验证性质 2
assert sp.simplify(sum2) == sp.simplify(sum2_split)

# 输出验证结果
print("性质 1 验证成功:", sp.simplify(sum1) == sp.simplify(sum1_out))
print("性质 2 验证成功:", sp.simplify(sum2) == sp.simplify(sum2_split))
