#include <stdio.h>

#define MAX_N 1005

int a[MAX_N][MAX_N]; // 原矩阵
int b[MAX_N][MAX_N]; // 差分矩阵

// 插入函数：对二维差分矩阵进行增量操作
void insert(int x1, int y1, int x2, int y2, int d) {
    b[x1][y1] += d;
    b[x2 + 1][y1] -= d;
    b[x1][y2 + 1] -= d;
    b[x2 + 1][y2 + 1] += d;
}

int main() {
    int n, m, q;
    scanf("%d%d%d", &n, &m, &q);
    
    // 输入原矩阵，并依次构造差分矩阵
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            scanf("%d", &a[i][j]);
            insert(i, j, i, j, a[i][j]);
        }
    }
    
    // 处理用户的操作
    while (q--) {
        int x1, y1, x2, y2, d;
        scanf("%d%d%d%d%d", &x1, &y1, &x2, &y2, &d);
        insert(x1, y1, x2, y2, d);  // 差分矩阵操作
    }
    
    // 计算差分矩阵的前缀和，也就是原矩阵的新值
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            a[i][j] = b[i][j];
            if (i > 1) a[i][j] += a[i-1][j];
            if (j > 1) a[i][j] += a[i][j-1];
            if (i > 1 && j > 1) a[i][j] -= a[i-1][j-1];
        }
    }
    
    // 输出新的矩阵值
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            printf("%d ", a[i][j]);
        }
        printf("\n");
    }
    
    return 0;
}
