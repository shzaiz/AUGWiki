#include <iostream>
using namespace std;

int main(){
    int i = 2;
    cout<< (i<<1) ;
}