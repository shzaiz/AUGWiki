#include<iostream>
#include<cstdio>
#include<cmath>
#define ull unsigned long long
using namespace std;
ull k,n;
void Gray(ull i,ull m){
	if(i==1){cout<<m;return ;}
	if(m>=pow(2ULL,i-1ULL)){
		printf("1");
		Gray(i-1ULL,pow(2ULL,i)-1ULL-m);
		return ;
	}else{
		printf("0");
		Gray(i-1,m);
		return ;
	}
}
int main(){
	cin>>n>>k;
	Gray(n,k);
	return 0;
}