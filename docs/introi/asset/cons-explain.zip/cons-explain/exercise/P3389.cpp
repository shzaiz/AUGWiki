#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

const int MAXN = 111;
double mat[MAXN][MAXN];  // 增广矩阵
double ans[MAXN];        // 解
const double EPSILON = 1e-7;

// 第一种初等变换：交换两行
void swapRows(int row1, int row2, int n) {
    for (int j = 1; j <= n + 1; j++) {
        swap(mat[row1][j], mat[row2][j]);
    }
}

// 第二种初等变换：将某一行的每个元素除以该行的第一个非零元素
void divideRow(int row, double divisor, int n) {
    for (int j = 1; j <= n + 1; j++) {
        mat[row][j] /= divisor;
    }
}

// 消去其他行的元素，使得矩阵成为上三角矩阵
void eliminate(int row, int col, int n) {
    for (int i = row + 1; i <= n; i++) {
        double factor = mat[i][col];
        for (int j = col; j <= n + 1; j++) {
            mat[i][j] -= mat[row][j] * factor;
        }
    }
}

int main() {
    int n;
    cin >> n;

    // 输入增广矩阵
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n + 1; j++) {
            cin >> mat[i][j];
        }
    }

    // 高斯消元法
    for (int i = 1; i <= n; i++) {
        // 找到第i列的最大值所在的行
        // insert code here

        // 如果第i列的最大值接近于零，则无解
        if (fabs(mat[maxRow][i]) < EPSILON) {
            cout << "No Solution" << endl;
            return 0;
        }

        // 交换第i行和最大值所在的行
        // insert code here

        // 将第i行的第一个非零元素化为1
        // insert code here

        // 消去第i列以下所有行的第i列元素
        // insert code here
    }

    // 回代求解
    for (int i = n; i >= 1; i--) {
        ans[i] = mat[i][n + 1];
        for (int j = i + 1; j <= n; j++) {
            ans[i] -= mat[i][j] * ans[j];
        }
    }

    // 输出解
    for (int i = 1; i <= n; i++) {
        cout << fixed << setprecision(2) << ans[i] << endl;
    }

    return 0;
}
