#define recursive
#ifdef recursive
#include <iostream>

// 函数声明
int T_I(int n);
int T_I_X(int n);

int main() {
    int n;
    std::cin >> n;

    int result_T_I = T_I(n);

    std::cout << result_T_I << std::endl;

    return 0;
}

// 计算 T_I(n) 的递归函数
int T_I(int n) {
    if (n == 1) {
        return 1;
    } else {
        return T_I_X(n - 1) + 2;
    }
}

// 计算 T_I_X(n) 的递归函数
int T_I_X(int n) {
    if (n == 1) {
        return 1;
    } else {
        return T_I(n - 1) + 1 + T_I_X(n - 1);
    }
}
#endif

#ifdef plain
#include <iostream>

#define MAX_N 100
int T_I[MAX_N + 1];
int T_I_X[MAX_N + 1];
int main() {
    int n;
    std::cin >> n;    
    
    // 初始化边界条件
    T_I[1] = 1;
    T_I_X[1] = 1;

    // 计算 T_I 和 T_I_X 的值
    for (int i = 2; i <= n; ++i) {
        T_I[i] = T_I_X[i - 1] + 2;
        T_I_X[i] = T_I[i - 1] + 1 + T_I_X[i - 1];
    }

    // 输出结果
    std::cout << T_I[n] << std::endl;

    return 0;
}
#endif