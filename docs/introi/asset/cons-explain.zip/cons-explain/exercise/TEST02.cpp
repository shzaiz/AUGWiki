#ifdef recursive
#include <iostream>


int T_I(int n);
int T_I_X(int n);

int main() {
    int n;
    std::cin >> n;

    int result_T_I = T_I(n);

    std::cout << result_T_I << std::endl;

    return 0;
}

// 计算 T_I(n) 的递归函数
int T_I(int n) {
    // insert code here
}

// 计算 T_I_X(n) 的递归函数
int T_I_X(int n) {
    // insert code here
}

