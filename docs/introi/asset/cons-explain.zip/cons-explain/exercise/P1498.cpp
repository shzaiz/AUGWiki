#include <iostream>
#include <vector>
#include <string>
using namespace std;

// 递归函数，用于生成Sierpinski三角形
void generateTriangle(vector<string>& triangle, int n, int row, int col, int size) {
    if (n == 0) {
        triangle[row][col] = '/';
        triangle[row][col + 1] = '\\';
        triangle[row + 1][col - 1] = '/';
        triangle[row + 1][col] = '_';
        triangle[row + 1][col + 1] = '_';
        triangle[row + 1][col + 2] = '\\';
    } else {
        int newSize = size / 2;
        generateTriangle(triangle, n - 1, row, col, newSize);
        generateTriangle(triangle, n - 1, row + newSize, col - newSize, newSize);
        generateTriangle(triangle, n - 1, row + newSize, col + newSize, newSize);
    }
}

// 打印Sierpinski三角形
void printTriangle(const vector<string>& triangle) {
    for (const auto& row : triangle) {
        cout << row.substr(1) << endl;
    }
}

int main() {
    int n;
    cin >> n;

    int size = (1 << n)+1;  // 2^n
    vector<string> triangle(size, string(2 * size - 1, ' '));

    generateTriangle(triangle, n - 1, 0, size - 1, size);

    printTriangle(triangle); 

    return 0;
}
