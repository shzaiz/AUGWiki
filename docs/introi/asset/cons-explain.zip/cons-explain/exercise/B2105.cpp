#include <iostream>
#include <iomanip>
using namespace std;

const int MAXN = 100;  // 矩阵的最大尺寸

int main() {
    int n, m, k;
    cin >> n >> m >> k;
    
    int A[MAXN][MAXN], B[MAXN][MAXN], C[MAXN][MAXN] = {0};

    // 输入矩阵A
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            cin >> A[i][j];
        }
    }

    // 输入矩阵B
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < k; ++j) {
            cin >> B[i][j];
        }
    }

    // 计算矩阵C = A * B
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < k; ++j) {
            C[i][j] = 0; // 初始化C[i][j]
            for (int l = 0; l < m; ++l) {
                C[i][j] += A[i][l] * B[l][j];
            }
        }
    }

    // 输出矩阵C
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < k; ++j) {
            if (j > 0) cout << " ";
            cout << C[i][j];
        }
        cout << endl;
    }

    return 0;
}
