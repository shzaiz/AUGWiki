#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// 将字符串表示的大数转换为倒序存储的vector
vector<int> stringToVector(const string &num) {
    vector<int> result(num.size());
    for (int i = 0; i < num.size(); ++i) {
        result[i] = num[num.size() - 1 - i] - '0';
    }
    return result;
}

// 高精度加法
vector<int> addVectors(const vector<int> &a, const vector<int> &b) {
    vector<int> result;
    int carry = 0;
    int maxSize = max(a.size(), b.size());

    for (int i = 0; i < maxSize; ++i) {
        int sum = carry;
        if (i < a.size()) sum += a[i];
        if (i < b.size()) sum += b[i];
        result.push_back(sum % 10);
        carry = sum / 10;
    }

    if (carry) result.push_back(carry);

    return result;
}

// 将倒序存储的vector转换为正常顺序的字符串
string vectorToString(const vector<int> &num) {
    string result;
    for (int i = num.size() - 1; i >= 0; --i) {
        result += to_string(num[i]);
    }
    return result;
}

int main() {
    string a, b;
    cin >> a >> b;

    vector<int> vecA = stringToVector(a);
    vector<int> vecB = stringToVector(b);

    vector<int> sum = addVectors(vecA, vecB);

    cout << vectorToString(sum) << endl;

    return 0;
}
