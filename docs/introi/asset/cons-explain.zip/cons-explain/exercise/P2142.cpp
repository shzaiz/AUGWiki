#include <iostream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

// 将字符串表示的大数转换为倒序存储的vector
vector<int> stringToVector(const string &num) {
    vector<int> result(num.size());
    for (int i = 0; i < num.size(); ++i) {
        result[i] = num[num.size() - 1 - i] - '0';
    }
    return result;
}

// 高精度减法
vector<int> subtractVectors(const vector<int> &a, const vector<int> &b) {
    vector<int> result;
    int borrow = 0;

    for (int i = 0; i < a.size(); ++i) {
        int sub = a[i] - borrow;
        if (i < b.size()) {
            sub -= b[i];
        }
        if (sub < 0) {
            sub += 10;
            borrow = 1;
        } else {
            borrow = 0;
        }
        result.push_back(sub);
    }

    // 去掉前导零
    while (result.size() > 1 && result.back() == 0) {
        result.pop_back();
    }

    return result;
}

// 将倒序存储的vector转换为正常顺序的字符串
string vectorToString(const vector<int> &num) {
    string result;
    for (int i = num.size() - 1; i >= 0; --i) {
        result += to_string(num[i]);
    }
    return result;
}

// 比较两个字符串表示的数字大小，返回 -1, 0 或 1 分别表示小于、等于或大于
int compareStrings(const string &a, const string &b) {
    if (a.size() > b.size()) return 1;
    if (a.size() < b.size()) return -1;
    for (int i = 0; i < a.size(); ++i) {
        if (a[i] > b[i]) return 1;
        if (a[i] < b[i]) return -1;
    }
    return 0;
}

int main() {
    string a, b;
    cin >> a >> b;

    // 比较 a 和 b 的大小，确保 a >= b
    if (compareStrings(a, b) < 0) {
        swap(a, b); cout<<"-";
    }

    vector<int> vecA = stringToVector(a);
    vector<int> vecB = stringToVector(b);

    vector<int> difference = subtractVectors(vecA, vecB);

    cout << vectorToString(difference) << endl;

    return 0;
}
