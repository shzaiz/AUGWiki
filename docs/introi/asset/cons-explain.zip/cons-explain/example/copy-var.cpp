#include <iostream>
using namespace std;

#ifdef CASE1
void a(int x, int y){
	x = x+1;
}

int main(){
	int x = 1, y = 2;
	int z = 1, w = 2;
	a(x, y); a(z, w);
	// 这时候x,y,z,w是多少?
    cout<<x<<" "<<y<<" "<<z<<" "<<w<<endl;
	return 0;
}
#endif
#ifdef CASE2
int x = 1, y = 2;
void a(int x, int y){
	x = x+1;
}

int main(){
	int z = 1, w = 2;
	a(x, y); a(z, w);
	// 这时候x,y,z,w是多少?
    cout<<x<<" "<<y<<" "<<z<<" "<<w<<endl;
	return 0;
}
#endif
#ifdef CASE3
int x = 1, y = 2;
void a(int q, int w){
	x = x+1;
}

int main(){
	int z = 1, w = 2;
	a(x, y); a(z, w);
	// 这时候x,y,z,w是多少?
    cout<<x<<" "<<y<<" "<<z<<" "<<w<<endl;
	return 0;
}

#endif