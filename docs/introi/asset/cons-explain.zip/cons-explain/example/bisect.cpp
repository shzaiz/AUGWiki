#include <iostream>
#include <cmath>
#include <vector>

// 递归函数：使用中点二分法计算平方根
double midpointBisectionSqrt(double n, double lower_bound, double upper_bound, double tolerance, std::vector<double>& iterations) {
    double midpoint = (lower_bound + upper_bound) / 2.0;
    iterations.push_back(midpoint);

    if (std::abs(midpoint * midpoint - n) <= tolerance) {
        return midpoint;
    }

    if (midpoint * midpoint < n) {
        return midpointBisectionSqrt(n, midpoint, upper_bound, tolerance, iterations);
    } else {
        return midpointBisectionSqrt(n, lower_bound, midpoint, tolerance, iterations);
    }
}

int main() {
    double number = 25.0;  // 要计算平方根的数
    double tolerance = 1e-7;  // 计算精度
    double lower_bound = 0.0;
    double upper_bound = number;
    std::vector<double> iterations;  // 存储每次迭代的中点值

    double result = midpointBisectionSqrt(number, lower_bound, upper_bound, tolerance, iterations);

    std::cout << "The approximate square root of " << number << " is " << result << std::endl;
    
    std::cout << "Iterations:" << std::endl;
    for (size_t i = 0; i < iterations.size(); ++i) {
        std::cout << "Iteration " << i + 1 << ": " << iterations[i] << std::endl;
    }

    return 0;
}
