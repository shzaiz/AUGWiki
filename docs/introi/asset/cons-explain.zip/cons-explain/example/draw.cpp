// Draws a soecial pattern, illustrating 2D loop

#include <math.h>
#include <iostream>
using namespace std;

bool f(int i, int j){
  double x = ((j * 2) / 15.0 - 3) / 2;
  double y = (i * 2) / 15.0 - 2;
  return pow(pow(x, 2) + pow(y, 2) - 1, 3) + \
             pow(x, 2) * pow(y, 3) < 0;
}

int main(){
    for(int i=0; i<=50; i++){
        for(int j=0; j<=50; j++){
            cout<< (f(i, j) ? "*" : " ");
        }
        cout<<endl;
    }
}