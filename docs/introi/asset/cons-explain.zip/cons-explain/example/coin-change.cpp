#include <stdio.h>

// 函数：根据硬币的种类返回硬币的面值
int first(int k) {
    switch (k) {
        case 1: return 1;
        case 2: return 5;
        case 3: return 10;
        case 4: return 25;
        case 5: return 50;
        default: return 0;
    }
}

// 递归函数：计算换零钱的不同方式数目
int cc(int amount, int kindOfCoins) {
    if (amount == 0) return 1; // 金额为0时，有1种换法（不需要硬币）
    if (amount < 0 || kindOfCoins == 0) return 0; // 金额小于0或没有硬币种类时，没有换法
    return cc(amount, kindOfCoins - 1) + cc(amount - first(kindOfCoins), kindOfCoins);
}

// 主函数：计算换零钱的不同方式数目
int count_change(int amount) {
    return cc(amount, 5); // 5种硬币
}

int main() {
    printf("%d\n", count_change(100)); // 输出将1美元换成零钱的不同方式数目
    return 0;
}
