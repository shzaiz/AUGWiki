#include <iostream>

#define FOR_TO_WHILE(init, condition, increment, body) \
    {\
        init; \
        while (condition) { \
            body\
            increment; \
        }\
    }

int main() {
    // 使用传统的for循环
    for (int i = 0; i < 10; ++i) {
        std::cout << "for loop: " << i << std::endl;
    }

    // 使用宏 FOR_TO_WHILE 来模拟 for 循环
    int j = 0;
    FOR_TO_WHILE(j = 0, j < 10, ++j, std::cout << "while loop: " << j << std::endl;)

    return 0;
}
