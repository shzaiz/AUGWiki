#include<iostream>
#include<algorithm>
#include <cstdlib>
using namespace std;
struct customer {
	int price;
	int amount;
} times[1000];
bool cmp(customer x, customer y) {
	return x.price <= y.price;
}
int  num,ans,cost=0,kill=0;
int main() {
	cin >> num >> ans;
	for (int i = 0; i < ans; i++) {
		cin >> times[i].price >> times[i].amount;
	}
	sort(times, times + ans, cmp);
	while (num > 0) {
		if (times[kill].amount <= num) {
			num -= times[kill].amount;
			cost +=( times[kill].amount*times[kill].price);
		} else {
			cost += (num*times[kill].price);
			num = 0;
		}
		kill+=1;
	}
	cout << cost;
	return 0;
}

