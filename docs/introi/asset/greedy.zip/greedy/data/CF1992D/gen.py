import random
import argparse

def generate_test_cases(t: int, max_n: int, max_k: int):
    """
    Generates test cases according to the given constraints.
    
    Args:
    t (int): Number of test cases.
    max_n (int): Maximum length of the river in each test case.
    max_k (int): Maximum number of meters ErnKor can swim without freezing.
    
    Returns:
    list of tuples: Each tuple contains (n, m, k, array) representing a test case.
    """
    test_cases = []
    total_n = 0
    
    for _ in range(t):
        # Ensure the sum of n over all test cases does not exceed 2*10^5
        remaining_n = max_n - total_n
        if remaining_n <= 0:
            break
        
        n = random.randint(1, min(200000, remaining_n))
        total_n += n
        m = random.randint(1, 10)
        k = random.randint(0, max_k)
        array = ''.join(random.choices(['W', 'C', 'L'], k=n))
        test_cases.append((n, m, k, array))
    
    return test_cases

def print_test_cases(test_cases):
    """
    Prints the test cases in the required format.
    
    Args:
    test_cases (list of tuples): Each tuple contains (n, m, k, array) representing a test case.
    """
    print(len(test_cases))
    for n, m, k, array in test_cases:
        print(n, m, k)
        print(array)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Generate test cases for the given constraints.')
    parser.add_argument('t', type=int, help='Number of test cases (1 ≤ t ≤ 10000)')
    parser.add_argument('max_n', type=int, help='Maximum sum of n over all test cases (≤ 2 * 10^5)')
    parser.add_argument('max_k', type=int, help='Maximum number of meters ErnKor can swim without freezing (≤ 2 * 10^5)')
    
    args = parser.parse_args()
    
    test_cases = generate_test_cases(args.t, args.max_n, args.max_k)
    print_test_cases(test_cases)
