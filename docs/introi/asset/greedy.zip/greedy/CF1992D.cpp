#include <stdio.h>
#include <string.h>
#include <stdbool.h>

#define MAXN 200005

int n, m, k;
char c[MAXN];

void solve() {
    memset(c, 0, sizeof(c));
    scanf("%d %d %d", &n, &m, &k);
    c[0] = 'L';
    c[n + 1] = 'L';

    for (int i = 1; i <= n; ++i) {
        scanf(" %c", &c[i]);
    }

    int i = 0;
    while (i <= n + 1) {
        if (i == n + 1) {
            printf("YES\n");
            return;
        }

        if (c[i] == 'W') {
            int j = i + 1;
            int steps = 1;
            while (j <= n + 1) {
                if (c[j] == 'C') {
                    printf("NO\n");
                    return;
                }
                if (c[j] == 'L') {
                    k -= steps;
                    if (k < 0) {
                        printf("NO\n");
                        return;
                    }
                    i = j;
                    break;
                }
                ++j;
                ++steps;
            }
            continue;
        }

        bool moved = false;
        int max_jump = (i + m < n + 1) ? i + m : n + 1;

        for (int j = max_jump; j >= i + 1; --j) {
            if (c[j] == 'L') {
                i = j;
                moved = true;
                break;
            }
        }

        if (moved) {
            continue;
        }

        for (int j = max_jump; j >= i + 1; --j) {
            if (c[j] == 'W') {
                i = j;
                moved = true;
                break;
            }
        }

        if (!moved) {
            printf("NO\n");
            return;
        }
    }
}

int main() {
    int t;
    scanf("%d", &t);
    while (t--) {
        solve();
    }
    return 0;
}

