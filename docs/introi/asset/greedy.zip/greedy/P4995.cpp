#include <iostream>
#include <algorithm>
using namespace std;
long long n,h[505],ans;
int main(){
   cin >> n;
   for(int i=1;i<=n;i++)cin >> h[i];
   sort(h,h+n+1);
   int l=0,r=n;
   while(r>l){
       ans+=(h[r]-h[l])*(h[r]-h[l]);
       l++;
       ans+=(h[l]-h[r])*(h[l]-h[r]);
       r--;
   }
   cout << ans;
   return 0;
}