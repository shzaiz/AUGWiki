#include <cstdio>
#include <vector>

using namespace std;

int main() {
    int t;
    scanf("%d", &t);

    while (t--) {
        int n;
        scanf("%d", &n);

        long long sum = 0;
        vector<int> initial(n);

        for (int i = 0; i < n; ++i) {
            scanf("%d", &initial[i]);
            sum += initial[i];
        }

        vector<int> after(n);
        vector<bool> occurred(n + 1, false);
        int current = 0;

        for (int i = 0; i < n; ++i) {
            if (initial[i] > current) {
                if (occurred[initial[i]]) {
                    current = initial[i];
                } else {
                    occurred[initial[i]] = true;
                }
            }
            sum += current;
            after[i] = current;
        }

        vector<int> after2(n);
        fill(occurred.begin(), occurred.end(), false);
        current = 0;

        for (int i = 0; i < n; ++i) {
            if (after[i] > current) {
                if (occurred[after[i]]) {
                    current = after[i];
                } else {
                    occurred[after[i]] = true;
                }
            }
            after2[i] = current;
        }

        for (int i = 0; i < n; ++i) {
            sum += static_cast<long long>(after2[i]) * (n - i);
        }

        printf("%lld\n", sum);
    }

    return 0;
}
