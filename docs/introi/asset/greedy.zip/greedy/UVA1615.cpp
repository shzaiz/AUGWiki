#include <cstdlib>
#include <algorithm>
#include <cstdio>
#include <cmath>

using namespace std;

struct Node {
    double left, right;
    
    bool operator<(const Node& A) const {
        if (left != A.left) {
            return left < A.left;
        } else {
            return right < A.right;
        }
    }
} nodes[10000];

int main() {
    int L, D, N;
    double x, y;

    while (scanf("%d %d %d", &L, &D, &N) != EOF) {
        for (int i = 0; i < N; i++) {
            scanf("%lf %lf", &x, &y);
            double delta = sqrt(D * D - y * y);
            nodes[i].left = x - delta;
            nodes[i].right = x + delta;
        }

        sort(nodes, nodes + N);

        double currentRight = nodes[0].right;
        int bridgeCount = 1;

        for (int i = 1; i < N; i++) {
            if (currentRight > L) {
                currentRight = L;
            }
            if (nodes[i].left > currentRight) {
                bridgeCount++;
                currentRight = nodes[i].right;
            } else {
                currentRight = min(nodes[i].right, currentRight);
            }
        }

        printf("%d\n", bridgeCount);
    }

    return 0;
}

