#include<bits/stdc++.h>
using namespace std;
int w,n,a[30005],tot=0;
bool f[30005];
int main() {
//	freopen("title.in","r",stdin);
//	freopen("title.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>w>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1,j=n;i<=n,j>=1;i++){
		if(f[i]){
			continue;
		}
		while(j>=i&&(f[j]||a[i]+a[j]>w)){
			j--;
		}
		f[j]=f[i]=1;
		tot++;
	}
	cout<<tot;
	return 0;
}
