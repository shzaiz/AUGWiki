#include <iostream>
using namespace std;
int main(){
	int numberNum,max;
	cin>>numberNum>>max;
	int nums[numberNum];
	for(int i=0;i<numberNum;i++){
		cin>>nums[i];
	}
	int ans=0; // starts dividing...
	int temp=0;
	for(int i=0;i<numberNum-1;i++){
		temp+=nums[i];
		if(temp+nums[i+1]>max) {
			ans++;
			temp=0;
		}
		
	}
	if(temp + nums[numberNum-1]>max) ans=ans+1;
	cout<<ans+1;
}