#include <iostream>
#include <queue>
using namespace std;

#define ll long long

struct Node {
    ll val;
    int dep;
    bool operator < (const Node &cmp) const {
        if (val != cmp.val) return val > cmp.val;
        return dep > cmp.dep;
    }
};

int main() {
    int n, k;
    ll ans = 0;
    priority_queue<Node> q;

    scanf("%d %d", &n, &k);

    for (int i = 1; i <= n; ++i) {
        ll x;
        scanf("%lld", &x);
        q.push(Node{x, 0});
    }

    int to_add = (k - 1 - (n - 1) % (k - 1)) % (k - 1);
    for (int i = 1; i <= to_add; ++i) {
        q.push(Node{0, 0});
    }

    while (q.size() > 1) {
        ll nval = 0;
        int ndep = 0;
        for (int i = 1; i <= k; ++i) {
            Node u = q.top();
            q.pop();
            nval += u.val;
            ndep = max(ndep, u.dep);
        }
        ans += nval;
        q.push(Node{nval, ndep + 1});
    }

    printf("%lld\n%d\n", ans, q.top().dep);
    return 0;
}
