#include <stdio.h>
#include <math.h>

#define MAXN 200005
#define EPSILON 1e-8

int a[MAXN];

void solve() {
    long long n, result = 0;
    scanf("%lld", &n);
    for (int i = 1; i <= n; ++i) {
        scanf("%d", &a[i]);
    }

    int previousValue = 0;
    for (int i = 2; i <= n; ++i) {
        if (a[i] == 1 && a[i - 1] != 1) {
            printf("-1\n");
            return;
        }
        double logDifference = log2(log2(a[i - 1])) - log2(log2(a[i])) - EPSILON;
        previousValue = fmax(ceil(previousValue + logDifference), 0);
        result += previousValue;
    }
    printf("%lld\n", result);
}

int main() {
    int T; scanf("%d", &T);
    while(T--){
        solve();
    }
    return 0;
}

